"""Copy the source MP3 packets and place every rendered video frame on its master timeline."""
from pathlib import Path
from fractions import Fraction
import av,json,subprocess
R=Path(__file__).resolve().parents[1]
D=Fraction(1697436735,1000000); OUT=R/'delivery/firefighting-before-engines-complete.mp4'
audiofile=R/'private/master-audio.mp4'
subprocess.run(['ffmpeg','-v','error','-y','-i',str(R/'private/voice.mp3'),'-map','0:a:0','-c:a','copy',str(audiofile)],check=True)
segments=json.loads((R/'renders/segments.json').read_text());containers=[av.open(x['file']) for x in segments]
audio=av.open(str(audiofile));out=av.open(str(OUT),'w',options={'movflags':'+faststart','movie_timescale':'1000000','video_track_timescale':'1000000'})
vs=out.add_stream_from_template(containers[0].streams.video[0]);vs.time_base=Fraction(1,1000000)
aus=out.add_stream_from_template(audio.streams.audio[0])
out.metadata.update(title='Как люди тушили пожары до пожарных машин?',artist='История в Палочках',comment='Original local 2D character animation with generated illustrated environment assets. Original Russian narration copied without re-encoding. No HeyGen cloud generation.')
vp=[]
for seg,con in zip(segments,containers):
 assert con.streams.video[0].codec_context.extradata==containers[0].streams.video[0].codec_context.extradata
 packets=[p for p in con.demux(video=0) if p.dts is not None]
 assert len(packets)==seg['end_frame']-seg['start_frame']
 for j,p in enumerate(packets):p.pts=p.dts=(seg['start_frame']+j)*40000;p.time_base=Fraction(1,1000000)
 vp+=packets
assert len(vp)==42436
patch_ranges=[]
for done in sorted((R/'renders/patches').glob('*.done')):
 item=json.loads(done.read_text());a=item['start_frame'];b=item['end_frame']
 con=av.open(item['file']);containers.append(con)
 assert con.streams.video[0].codec_context.extradata==containers[0].streams.video[0].codec_context.extradata
 packets=[p for p in con.demux(video=0) if p.dts is not None]
 assert len(packets)==b-a and packets[0].is_keyframe
 for j,p in enumerate(packets):p.pts=p.dts=(a+j)*40000;p.time_base=Fraction(1,1000000)
 vp[a:b]=packets;patch_ranges.append([a,b])
for a,b in patch_ranges:
 if b<len(vp):assert vp[b].is_keyframe,('Unsafe refinement boundary',a,b)
vp[-1].duration=int(D/vp[-1].time_base)-vp[-1].pts
assert vp[-1].duration==36735
ap=[p for p in audio.demux(audio=0) if p.dts is not None];i=j=0
while i<len(vp) or j<len(ap):
 take=j==len(ap) or i<len(vp) and vp[i].dts*vp[i].time_base<=ap[j].dts*ap[j].time_base
 if take:p=vp[i];p.stream=vs;i+=1
 else:p=ap[j];p.stream=aus;j+=1
 out.mux(p)
out.close();audio.close()
for con in containers:con.close()
report=dict(video_frames=len(vp),audio_packets_copied=len(ap),source_audio_reencoded=False,target_duration_seconds=float(D),last_video_presentation_interval_seconds=.036735,nominal_fps=25,refinement_frame_ranges=patch_ranges)
(R/'delivery/mux-report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
