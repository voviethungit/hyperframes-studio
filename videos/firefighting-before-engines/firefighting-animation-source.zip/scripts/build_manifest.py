from pathlib import Path
import json,re,csv,hashlib,subprocess,statistics,shutil
R=Path(__file__).resolve().parents[1]; O=R/'deliverables'
P=json.loads((O/'phrase-alignment.json').read_text())
duration=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',str(R/'private/voice.mp3')]))
tokens=[]
for p in P:
    m=list(re.finditer(r'[А-Яа-яЁё]+|[A-Za-z]+',p['text']))
    assert len(m)==len(p['words']),(p['line'],len(m),len(p['words']))
    for i,(match,w) in enumerate(zip(m,p['words'])):
        tokens.append(dict(**w,word=i,raw_start=match.start(),raw_end=match.end()))
idx={(w['line'],w['word']):i for i,w in enumerate(tokens)}
def tc(s):
    ms=round(s*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02}.{ms%1000:03}'
spec=[]
for row in (R/'scripts/shots.tsv').read_text().splitlines():
    if not row or row.startswith('#'):continue
    a,f,v,c,l,d=row.split('|'); parts=a.split(':'); ln=int(parts[0]); wi=int(parts[1]) if len(parts)>1 else 0
    spec.append(dict(anchor=a,line=ln,word=wi,family=f,variant=v,camera=c,label=l,action=d,token=idx[(ln,wi)]))
assert all(a['token']<b['token'] for a,b in zip(spec,spec[1:]))
PROPS={
 'street':['period timber buildings','prepared household tools'], 'roof':['tiled or wooden roof','water bucket','ember'],
 'interior':['hearth','candle','wooden furniture','stored fuel'], 'modern':['modern fire engine','ladder','pump panel'],
 'tools':['wooden bucket','leather bucket','hook pole','axe','crowbar','wooden ladder'],
 'bucket':['stone well','wooden buckets','full outbound line','empty return line'],
 'demolition':['hook pole','wooden connector','rope','clear fall zone'], 'map':['illustrated district','water source','fuel connections'],
 'sand':['sand bin','small heat source','oil container'], 'hazard':['falling timber','burning facade','smoke'],
 'ladder':['wooden ladder','upper window','bucket','supporting crew'], 'horse':['horse','bridle','harness','cart'],
 'river':['river','quay','water buckets','period hand tools'], 'storage':['barrels','cistern','buckets'],
 'pump':['manual beam pump','reservoir','pistons','water jet'], 'hose':['stitched leather hose','period pump','nozzle'],
 'station':['organized equipment racks','stable','manual pump'], 'tower':['lookout platform','bell','rope','lantern'],
 'rescue':['chest','documents','tools','resident'], 'winter':['ice','wet hose','wool coat','bucket'],
 'insurance':['ledger','geometric insurance mark','building'], 'hydrant':['water main','period access fitting','pump connection'],
 'steam':['boiler','piston','flywheel','horse-drawn pump cart'], 'compare':['explicit separated historical and modern comparison']}
def bg(s):
 f=s['family'];v=s['variant'];ln=s['line']
 if f=='pump' and v in ['ancient','section']:return 'ancient'
 if f=='street' and v=='aftermath':return 'aftermath'
 if f=='modern':return 'modern'
 if f in ['interior','sand','insurance']:return 'workshop'
 if f=='map':return 'map'
 if f=='tower':return 'tower'
 if f=='station':return 'station'
 if f=='horse' and v in ['stable','blindfold','fear','rescue']:return 'stable'
 if f=='river':return 'river'
 if f=='winter':return 'winter'
 if f=='tools':return 'station' if ln>=359 else 'workshop'
 if 251<=ln<=271 or ln>=563 or f=='street' and v in ['chaos','night','nightfire','patrol']:return 'night'
 return 'alternate' if 35<=ln<=147 or 179<=ln<=210 or 277<=ln<=358 else 'day'
scenes=[]; sequence=0;oldgroup=None
for i,s in enumerate(spec):
 a=s['token'];b=spec[i+1]['token'] if i+1<len(spec) else len(tokens)
 selected=tokens[a:b];start=0.0 if i==0 else selected[0]['start'];end=tokens[b]['start'] if b<len(tokens) else duration
 excerpts=[]
 for ln in dict.fromkeys(w['line'] for w in selected):
  p=P[ln-1];local=[w for w in selected if w['line']==ln]
  left=0 if local[0]['word']==0 else local[0]['raw_start'];right=len(p['text']) if local[-1]['word']==len(p['words'])-1 else local[-1]['raw_end']
  excerpts.append(p['text'][left:right].strip())
 s['background']=bg(s)
 # Adjacent compatible families share operation time and crew identity. Camera cuts never reset mechanics.
 group='water-operation' if s['family'] in ['pump','hose'] else s['family']
 group+=(s['background'])
 if group!=oldgroup:sequence+=1;sequence_start=start
 oldgroup=group
 item=dict(scene_number=i+1,scene_id=f'S{i+1:03}',start_seconds=start,end_seconds=end,duration_seconds=round(end-start,6),start_timecode=tc(start),end_timecode=tc(end),narration_ru='\n'.join(excerpts),visual_description_en=s['action'],main_action=s['action'],key_props=PROPS[s['family']],continuity_note=f"Sequence Q{sequence:03}: same identifiable teal water worker, red tool worker, ochre coordinator and blue pump operator; preserve equipment placement, source, travel direction, fire state and lighting. {'New location/action established.' if start==sequence_start else 'Continue operation time and object states from previous shot.'}",sequence_id=f'Q{sequence:03}',sequence_start=sequence_start,family=s['family'],variant=s['variant'],camera=s['camera'],background=s['background'],overlay_ru=s['label'] or None,script_lines=sorted(set(w['line'] for w in selected)),anchor=s['anchor'],generation_asset_id=f'local-canvas:{i+1:03}',heygen_asset_id=None,generation_status='planned',spoken_start=selected[0]['start'],spoken_end=selected[-1]['end'])
 scenes.append(item)
for a,b in zip(scenes,scenes[1:]):assert a['end_seconds']==b['start_seconds']
assert scenes[0]['start_seconds']==0 and scenes[-1]['end_seconds']==duration
meta=dict(channel='История в Палочках',title='Как люди тушили пожары до пожарных машин?',duration_seconds=duration,width=1920,height=1080,fps=25,source_audio_sha256=hashlib.sha256((R/'private/voice.mp3').read_bytes()).hexdigest(),script_sha256=hashlib.sha256((R/'private/source-script.txt').read_bytes()).hexdigest(),audio_unchanged=True,heygen_available=False,production_engine='Original 2D Canvas animation with generated cartoon environment assets; FFmpeg/PyAV export',alignment='Russian GigaAM v2 CTC acoustic forced alignment, 40ms grid; not a manual sample-accurate phonetic review')
manifest=dict(project=meta,scenes=scenes)
(O/'scene-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
fields=['scene_number','scene_id','start_timecode','end_timecode','start_seconds','end_seconds','duration_seconds','narration_ru','visual_description_en','main_action','key_props','continuity_note','generation_asset_id']
with (O/'scene-manifest.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=fields,lineterminator='\n');w.writeheader()
 for s in scenes:w.writerow({k:'; '.join(s[k]) if isinstance(s[k],list) else s[k] for k in fields})
(R/'assets/manifest.json').write_text(json.dumps(manifest,ensure_ascii=False))
(R/'assets/phrases.json').write_text(json.dumps(P,ensure_ascii=False))
print(json.dumps(dict(scene_count=len(scenes),duration=duration,min= min(s['duration_seconds'] for s in scenes),median=statistics.median(s['duration_seconds'] for s in scenes),max=max(s['duration_seconds'] for s in scenes),long=[(s['scene_id'],s['anchor'],s['duration_seconds']) for s in scenes if s['duration_seconds']>20]),indent=2))
