from pathlib import Path
import json,csv,shutil,zipfile,hashlib,math,subprocess
R=Path(__file__).resolve().parents[1];PUB=Path('/workspace/hyperframes-studio/videos/firefighting-before-engines');PUB.mkdir(parents=True,exist_ok=True)
Q=json.loads((R/'deliverables/qa-report.json').read_text());assert Q['final_export_succeeded'] and Q['narration_remained_unchanged'] and not Q['timeline_gaps']
Q['final_animation_source_sha256']=hashlib.sha256((R/'film.js').read_bytes()).hexdigest()
Q['base_render_animation_source_sha256']=hashlib.sha256((R/'private/film-base-render.js').read_bytes()).hexdigest()
Q['connection_refinements']=json.loads((R/'private/qc/refinement-ranges.json').read_text())
(R/'deliverables/qa-report.json').write_text(json.dumps(Q,ensure_ascii=False,indent=2))
M=json.loads((R/'deliverables/scene-manifest.json').read_text());M['project']['finished_video_created']=True;M['project']['final_video']='firefighting-before-engines-complete.mp4'
for s in M['scenes']:
 s['generation_status']='rendered_original_local_2d_animation'
 s['first_video_frame']=math.ceil(s['start_seconds']*25);s['end_video_frame_exclusive']=min(42436,math.ceil(s['end_seconds']*25))
 s['final_video_asset']=f"firefighting-before-engines-complete.mp4#t={s['start_seconds']:.6f},{s['end_seconds']:.6f}"
(R/'deliverables/scene-manifest.json').write_text(json.dumps(M,ensure_ascii=False,indent=2));(R/'assets/manifest.json').write_text(json.dumps(M,ensure_ascii=False))
fields=['scene_number','scene_id','start_timecode','end_timecode','start_seconds','end_seconds','duration_seconds','narration_ru','visual_description_en','main_action','key_props','continuity_note','generation_asset_id','generation_status','final_video_asset']
with (R/'deliverables/scene-manifest.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=fields,lineterminator='\n');w.writeheader()
 for s in M['scenes']:w.writerow({k:'; '.join(s[k]) if isinstance(s[k],list) else s[k] for k in fields})
subprocess.run(['python3',str(R/'scripts/build.py')],check=True)
for name in ['scene-manifest.csv','scene-manifest.json','qa-report.md','qa-report.json','alignment-report.json','asset-provenance.json','phrase-alignment.json','word-alignment.json','browser-playback-check.json']:
 shutil.copy2(R/'deliverables'/name,PUB/name)
shutil.copy2(R/'delivery/mux-report.json',PUB/'mux-report.json')
shutil.copy2(R/'private/qc/motion-report.json',PUB/'motion-report.json')
shutil.copy2(R/'DESIGN.md',PUB/'DESIGN.md');shutil.copy2(R/'delivery/REPRODUCE.md',PUB/'REPRODUCE.md')
V=R/'delivery/firefighting-before-engines-complete.mp4';assert V.stat().st_size<100*1024*1024,('GitHub file size limit',V.stat().st_size)
shutil.copy2(V,PUB/V.name)
subprocess.run(['ffmpeg','-v','error','-y','-ss','1.54','-i',str(V),'-frames:v','1',str(PUB/'preview.jpg')],check=True)
with zipfile.ZipFile(PUB/'firefighting-animation-source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for rel in ['index.html','film.js','DESIGN.md']:
  z.write(R/rel,rel)
 z.write(R/'delivery/REPRODUCE.md','REPRODUCE.md')
 for folder in ['assets','scripts']:
  for p in sorted((R/folder).rglob('*')):
   if p.is_file() and '__pycache__' not in p.parts:z.write(p,str(p.relative_to(R)))
BASE='https://raw.githubusercontent.com/voviethungit/hyperframes-studio/main/videos/firefighting-before-engines/'
(PUB/'README.md').write_text(f'''# Как люди тушили пожары до пожарных машин?

История в Палочках · полный фильм · **28:17.436735 · 1920×1080 · 16:9 · 25 fps**

## Finished video

[Download the complete MP4]({BASE}{V.name})

![Frame from the finished film](preview.jpg)

The supplied Russian MP3 remains the final narration. No new voice, re-recording, speed adjustment, dialogue, lip sync, automatic subtitles, music or SFX were added. Encoded narration packet payload and decoded PCM were both verified identical to the source. Final visual coverage begins at zero and ends at the original MP3 container endpoint.

## Scene manifest

[CSV]({BASE}scene-manifest.csv) · [JSON]({BASE}scene-manifest.json)

256 manually authored semantic shots, aligned to 568 Russian script phrases and 3,645 spoken words with a Russian acoustic CTC model. The scene boundaries follow ideas and actions, not fixed-length blocks.

## QA report

[Readable report](qa-report.md) · [Machine-readable report]({BASE}qa-report.json)

Every scene composition was inspected; motion was sampled within every scene and key mechanisms received additional phase checks. The entire exported file was decoded and checked for black intervals. A continuous real-time human viewing was not performed. See the QA report for the exact review scope and alignment limits.

## Production source

[Download animation source]({BASE}firefighting-animation-source.zip) · [Reproduction instructions](REPRODUCE.md) · [Art direction](DESIGN.md)

This is an original locally animated Canvas2D film with 13 generated cartoon environment assets, assembled with FFmpeg/PyAV. Authenticated HeyGen motion generation was unavailable and was not used. The source archive excludes the standalone narration recording, uploaded reference videos and speech-model weights. No cloud-generated motion clip identifiers are invented; manifest asset IDs identify the local animation scenes.

SHA256 of final MP4: `{Q['final_video_sha256']}`
''')
print(json.dumps({'public_folder':str(PUB),'video_bytes':V.stat().st_size,'source_zip_bytes':(PUB/'firefighting-animation-source.zip').stat().st_size,'video_sha256':Q['final_video_sha256']},indent=2))
