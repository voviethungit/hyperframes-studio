from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
M=json.loads((R/'assets/manifest.json').read_text());M['phrases']=json.loads((R/'assets/phrases.json').read_text())
data=json.dumps(M,ensure_ascii=False).replace('</','<\\/')
html='''<!doctype html><html lang="ru"><meta charset="utf-8"><title>История в Палочках — Как люди тушили пожары</title><style>*{box-sizing:border-box}html,body{margin:0;width:1920px;height:1080px;overflow:hidden;background:#283338}canvas{display:block;width:1920px;height:1080px}</style><canvas id="film" width="1920" height="1080"></canvas><script>window.FILM_DATA=__DATA__;</script><script src="film.js"></script></html>'''
(R/'index.html').write_text(html.replace('__DATA__',data))
print('Built',len(M['scenes']),'semantic scenes')
