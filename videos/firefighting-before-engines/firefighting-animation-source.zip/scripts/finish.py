"""Complete the reviewed connection refinements after the base render, then export and verify."""
from pathlib import Path
import json,time,subprocess,bisect,sys
import av
R=Path(__file__).resolve().parents[1]
while not (R/'renders/segments.json').exists():time.sleep(3)
segments=json.loads((R/'renders/segments.json').read_text());assert sum(x['end_frame']-x['start_frame'] for x in segments)==42436
keys=[]
for seg in segments:
 con=av.open(seg['file'])
 for i,p in enumerate(p for p in con.demux(video=0) if p.dts is not None):
  if p.is_keyframe:keys.append(seg['start_frame']+i)
 con.close()
keys=sorted(set(keys+[42436]));M=json.loads((R/'assets/manifest.json').read_text())
affected=[s for s in M['scenes'] if s['family'] in ['hose','winter','modern','compare','demolition'] or s['family']=='pump' and s['variant'] in ['supply','roles','team','organize','mainsupply','pressure','later','shortage'] or s['family']=='station' and s['variant']=='maintenance' or s['family']=='ladder' and s['variant']=='carry' or s['family']=='steam' and s['variant']=='pressure']
ranges=[]
import math
for s in affected:
 a=math.floor(s['start_seconds']*25);last=math.ceil(s['end_seconds']*25)
 b=keys[min(bisect.bisect_left(keys,last),len(keys)-1)]
 if ranges and a<=ranges[-1][1]+100:
  ranges[-1][1]=max(ranges[-1][1],b);ranges[-1][2].append(s['scene_id'])
 else:ranges.append([a,b,[s['scene_id']]])
(R/'private/qc/refinement-ranges.json').write_text(json.dumps(ranges,indent=2))
print('REFINEMENTS',len(affected),'scenes,',len(ranges),'frame ranges',sum(b-a for a,b,_ in ranges),'frames',flush=True)
# Each replacement begins with an I-frame and ends before an existing I-frame.
for i,(a,b,ids) in enumerate(ranges):
 print('REFINEMENT',i+1,len(ranges),a,b,ids,flush=True)
 subprocess.run(['node',str(R/'scripts/render.cjs'),'--start',str(a),'--frames',str(b-a),'--workers','2','--out',str(R/'renders/patches')],check=True)
subprocess.run([sys.executable,str(R/'scripts/mux.py')],check=True)
subprocess.run(['node',str(R/'scripts/inspect.cjs')],check=True)
subprocess.run(['node',str(R/'scripts/motion.cjs')],check=True)
subprocess.run([sys.executable,str(R/'scripts/verify.py')],check=True)
print('PRODUCTION_EXPORT_VERIFIED',flush=True)
