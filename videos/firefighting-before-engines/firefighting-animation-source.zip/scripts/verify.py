from pathlib import Path
import av,json,subprocess,hashlib,re
R=Path(__file__).resolve().parents[1];V=R/'delivery/firefighting-before-engines-complete.mp4';A=R/'private/voice.mp3'
def probe(p):return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(p)]))
def payload(p):
 con=av.open(str(p));h=hashlib.sha256();n=0
 for p in con.demux(audio=0):
  if p.dts is not None:h.update(bytes(p));n+=1
 con.close();return dict(sha256=h.hexdigest(),packets=n)
def pcm(p):return subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-map','0:a:0','-acodec','pcm_s16le','-f','hash','-hash','sha256','-'],text=True).strip()
source=probe(A);final=probe(V);v=next(s for s in final['streams'] if s['codec_type']=='video')
sp=payload(A);fp=payload(V);sd=pcm(A);fd=pcm(V)
assert sp==fp,(sp,fp);assert sd==fd,(sd,fd)
assert v['width']==1920 and v['height']==1080 and int(v['nb_frames'])==42436
target=float(source['format']['duration']);actual=float(final['format']['duration']);assert abs(target-actual)<.00001,(target,actual)
con=av.open(str(V));packets=[p for p in con.demux(video=0) if p.dts is not None]
gaps=[]
for a,b in zip(packets,packets[1:]):
 if abs(float((a.pts+a.duration)*a.time_base-b.pts*b.time_base))>.000001:gaps.append([a.pts,b.pts])
assert not gaps
end=float((packets[-1].pts+packets[-1].duration)*packets[-1].time_base);con.close();assert abs(end-target)<.000001
# Full file decode and all-frame black detection, with no audio alteration.
check=subprocess.run(['ffmpeg','-hide_banner','-nostats','-progress','pipe:1','-xerror','-err_detect','explode','-i',str(V),'-vf','blackdetect=d=0.02:pix_th=0.07','-f','null','-'],capture_output=True,text=True)
(R/'private/qc/full-decode.log').write_text(check.stderr);assert check.returncode==0
black=[x for x in check.stderr.splitlines() if 'black_start:' in x];assert not black,black
decoded_counts=re.findall(r'frame=\s*(\d+)',check.stdout);assert decoded_counts and int(decoded_counts[-1])==42436,decoded_counts
M=json.loads((R/'deliverables/scene-manifest.json').read_text());motion=json.loads((R/'private/qc/motion-report.json').read_text());inspection=json.loads((R/'private/qc/scene-inspection.json').read_text())
assert not inspection['errors'];assert all(x['nonblack'] for x in inspection['checks'])
report=dict(source_audio_duration_seconds=target,final_video_duration_seconds=actual,final_video_timecode='28:17.436735',resolution='1920x1080',aspect_ratio='16:9',nominal_frame_rate=25,total_video_frames=42436,final_frame_duration_seconds=.036735,total_scene_count=len(M['scenes']),narration_remained_unchanged=True,original_mp3_payload=sp,final_mp3_payload=fp,original_decoded_pcm_sha256=sd,final_decoded_pcm_sha256=fd,audio_reencoded=False,timeline_gaps=False,uncovered_narration_seconds=0,black_intervals=black,full_file_decode_passed=True,scene_inspection_count=len(inspection['checks']),javascript_errors=inspection['errors'],sampled_motion_static_flags=[x for x in motion['results'] if x['static_flag']],continuity_passed=True,continuity_review_scope='Deterministic persistent sequence time and role identities; visual review of every scene midpoint plus start/mid/end samples for key mechanisms. Not a continuous real-time human watch or proof of every intermediate pose.',style_lock_passed=True,style_review_scope='Polished illustrated 2D cartoon environment assets, rounded solid-body characters, no 3D or photorealistic humans; all scene compositions inspected. Artistic quality remains a reviewer judgment.',final_export_succeeded=True,heygen_used=False,production_engine='Original Canvas2D animation, generated 2D background assets, FFmpeg/PyAV assembly',source_audio_sha256=hashlib.sha256(A.read_bytes()).hexdigest(),final_video_sha256=hashlib.sha256(V.read_bytes()).hexdigest(),final_file_bytes=V.stat().st_size,alignment_method=M['project']['alignment'],alignment_limitations='Acoustic timing uses a 40 ms model grid; script is not independently historically fact-checked; not manually verified at each phoneme.')
(R/'deliverables/qa-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
md=f'''# QA report — История в Палочках

Video: Как люди тушили пожары до пожарных машин?

| Check | Result |
|---|---|
| Source narration | {target:.6f} s |
| Final video | {actual:.6f} s — 28:17.436735 |
| Resolution / ratio | 1920×1080 / 16:9 |
| Nominal frame rate | 25 fps; 42,436 frames |
| Final presentation interval | 36.735 ms, to meet the original MP3 endpoint |
| Semantic scenes | {len(M['scenes'])} |
| Narration unchanged | PASS — encoded MP3 packet payload and decoded PCM both identical |
| Narration re-encoded, replaced or stretched | No |
| Missing timeline coverage | None |
| Black gaps | None found by all-frame black detection |
| Full video and audio decode | PASS |
| Scene composition inspection | {len(inspection['checks'])} scenes, zero JavaScript errors |
| Continuity | PASS within the review scope below |
| Style lock | PASS within the review scope below |
| Export | PASS |
| HeyGen generation | Not used; authenticated HeyGen capability unavailable |

## Review scope

The entire narration has acoustically aligned semantic coverage. Every scene midpoint was visually inspected. Motion was sampled at 20%, 50%, and 80% of each scene. Key bucket, pump, ladder, hose, rescue and demolition actions received additional phase checks. The complete exported file was decoded and checked for black intervals.

Continuity uses deterministic sequence time, fixed role colors, consistent geography and stable mechanism positions. Style uses 13 generated cartoon environment assets and original solid-body 2D character animation. This is a locally animated finished film, not a HeyGen-generated film. A continuous real-time human viewing of all 28 minutes was not performed; sampled inspection cannot guarantee every intermediate pose. Acoustic alignment is model-derived on a 40 ms grid, not sample-accurate human phonetic annotation. Historical statements follow the supplied script and simplified illustrative reconstructions.

## Integrity

- Original MP3 SHA256: `{report['source_audio_sha256']}`
- Final MP4 SHA256: `{report['final_video_sha256']}`
- Encoded narration payload SHA256: `{sp['sha256']}`
- File size: {V.stat().st_size:,} bytes.
'''
(R/'deliverables/qa-report.md').write_text(md)
print(json.dumps(report,ensure_ascii=False,indent=2))
