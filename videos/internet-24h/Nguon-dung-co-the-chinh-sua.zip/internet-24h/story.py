"""Editable Vietnamese narration and shot intentions. No generated voice."""
CHAPTERS = [{'id': '01',
  'title': 'Một buổi sáng không kết nối',
  'beats': [{'key': 'wake',
             'bg': 'home',
             'kind': 'phone',
             'mood': 'curious',
             'label': '07:00',
             'text': 'Bảy giờ sáng. Chuông báo thức vẫn reo, chiếc đèn vẫn sáng, và Minh vẫn muốn ngủ thêm năm '
                     'phút. Cậu với lấy điện thoại, định xem vài tin nhắn trước khi ra khỏi giường. Nhưng vòng '
                     'tròn trên màn hình cứ quay. Chờ thêm một chút. Rồi thêm một chút nữa. Có vẻ hôm nay, cả '
                     'chiếc điện thoại cũng chưa muốn thức dậy.'},
            {'key': 'refresh',
             'bg': 'home',
             'kind': 'refresh',
             'mood': 'worry',
             'label': 'Đang kết nối…',
             'text': 'Minh làm điều mà rất nhiều người từng làm: kéo xuống để tải lại. Không được. Đóng ứng dụng, '
                     'mở lại. Vẫn không được. Tắt Wi-Fi, bật dữ liệu di động. Kết quả chẳng khá hơn. Mấy phút '
                     'trước, cậu còn lo không biết sáng nay có bao nhiêu việc phải làm. Bây giờ, cậu chỉ muốn một '
                     'thứ rất nhỏ: một dòng tin nhắn hiện ra.'},
            {'key': 'router',
             'bg': 'home',
             'kind': 'router',
             'mood': 'think',
             'label': 'Wi-Fi vẫn sáng',
             'text': 'Cậu bước đến bộ phát mạng, nhìn những đèn báo nhấp nháy như đang tìm lời thú nhận. Rút '
                     'điện, cắm lại. Đứng chờ. Thiết bị trở lại hoạt động, nhưng trang web vẫn không mở. Lần đầu '
                     'tiên trong buổi sáng, Minh nhận ra biểu tượng Wi-Fi đầy vạch không hứa rằng cậu sẽ đi được '
                     'ra ngoài Internet.'},
            {'key': 'neighbour',
             'bg': 'street',
             'kind': 'talk',
             'mood': 'curious',
             'label': 'Nhà anh cũng vậy?',
             'text': 'Ngoài cửa, người hàng xóm cũng đang giơ điện thoại lên rồi hạ xuống. Hai người nhìn nhau. '
                     'Nhà anh cũng vậy à? Chỉ một câu hỏi ngắn đã biến một lỗi tưởng như của riêng Minh thành một '
                     'chuyện lớn hơn. Dọc con phố, nhiều người đang thử cùng một động tác. Không phải màn hình '
                     'nào hỏng. Các ứng dụng cần kết nối đều đang mắc kẹt.'},
            {'key': 'premise',
             'bg': None,
             'kind': 'premise',
             'mood': 'neutral',
             'label': '24 giờ không Internet',
             'text': 'Bây giờ, hãy đặt ra một giả định: Internet công cộng bị gián đoạn trên diện rộng trong hai '
                     'mươi bốn giờ. Điện vẫn còn. Máy móc không tự nhiên biến mất. Một số mạng nội bộ và dịch vụ '
                     'viễn thông vẫn có thể hoạt động. Đây là một tình huống giả tưởng để nhìn vào sự phụ thuộc '
                     'của chúng ta. Và Minh sẽ phải đi qua ngày hôm ấy.'}]},
 {'id': '02',
  'title': 'Chiếc điện thoại chưa thành cục gạch',
  'beats': [{'key': 'device',
             'bg': 'home',
             'kind': 'offline-phone',
             'mood': 'happy',
             'label': 'Vẫn dùng được',
             'text': 'Điều ngạc nhiên đầu tiên là chiếc điện thoại chưa trở thành cục gạch. Minh vẫn chụp được '
                     'ảnh, mở lịch đã lưu, đọc ghi chú và bật bài nhạc nằm sẵn trong máy. Những việc ấy không cần '
                     'gọi đến một máy chủ ở xa. Thứ cậu mất lúc này là khả năng lấy dữ liệu mới, hoặc gửi dữ liệu '
                     'đi qua phần mạng đang bị gián đoạn.'},
            {'key': 'wifi',
             'bg': None,
             'kind': 'network',
             'mood': 'curious',
             'label': 'Wi-Fi ≠ Internet',
             'text': 'Hãy hình dung Wi-Fi như con đường nhỏ từ điện thoại đến bộ phát trong nhà. Internet là mạng '
                     'lưới rộng hơn nối rất nhiều mạng lại với nhau. Con đường nhỏ vẫn thông, nhưng lối đi tiếp '
                     'có thể đang bị chặn. Bởi vậy, máy tính và máy in trong cùng một mạng vẫn có thể nói chuyện '
                     'với nhau, trong khi một trang web ở xa thì không.'},
            {'key': 'call',
             'bg': 'street',
             'kind': 'call',
             'mood': 'happy',
             'label': 'Thử gọi thường',
             'text': 'Minh thử gọi cho đồng nghiệp bằng cuộc gọi điện thoại thông thường. Trong câu chuyện này, '
                     'mạng của nhà cung cấp vẫn giữ được dịch vụ thoại, nên cuộc gọi kết nối. Điều đó không được '
                     'bảo đảm cho mọi sự cố, bởi hạ tầng viễn thông cũng có những phụ thuộc riêng. Nhưng ít nhất, '
                     'Minh đã tìm ra một cách liên lạc ngoài ứng dụng nhắn tin quen thuộc.'},
            {'key': 'gps',
             'bg': None,
             'kind': 'gps',
             'mood': 'think',
             'label': 'Vị trí ≠ bản đồ',
             'text': 'Còn định vị thì sao? Tín hiệu vệ tinh giúp máy xác định vị trí không nhất thiết cần '
                     'Internet. Nhưng một dấu chấm vị trí và một tấm bản đồ là hai chuyện khác nhau. Nếu khu vực '
                     'ấy chưa được lưu trong máy, bản đồ có thể không hiện đủ. Các thông tin trực tiếp như tình '
                     'trạng giao thông cũng không còn cập nhật như thường lệ.'},
            {'key': 'address',
             'bg': 'home',
             'kind': 'address',
             'mood': 'happy',
             'label': 'Địa chỉ trên giấy',
             'text': 'Minh tìm được địa chỉ văn phòng trong một ghi chú cũ. Cậu chép nó ra giấy, kèm một số điện '
                     'thoại liên hệ. Tờ giấy không có tính năng gợi ý đường đi, nhưng cũng không cần đăng nhập. '
                     'Cậu bỏ nó vào túi, cầm chìa khóa và ra ngoài. Buổi sáng chỉ mới bắt đầu, mà những việc rất '
                     'quen đã phải làm theo một trình tự khác.'}]},
 {'id': '03',
  'title': 'Đi đến công ty bằng cách nào?',
  'beats': [{'key': 'ride',
             'bg': 'street',
             'kind': 'ride',
             'mood': 'worry',
             'label': 'Ứng dụng đang chờ',
             'text': 'Bình thường, Minh mở ứng dụng gọi xe rồi đứng chờ tài xế. Hôm nay, phần mềm không lấy được '
                     'dữ liệu cần thiết để đặt chuyến. Những chiếc xe ngoài đường vẫn chạy. Điều bị gián đoạn là '
                     'cách ứng dụng ghép một người đang cần đi với một người có thể chở. Minh nhìn lên khỏi màn '
                     'hình, bắt đầu quan sát những lựa chọn thật sự có mặt quanh mình.'},
            {'key': 'map',
             'bg': None,
             'kind': 'map',
             'mood': 'think',
             'label': 'Bản đồ đã lưu',
             'text': 'Một người đi cùng có bản đồ khu vực đã tải về từ trước. Nó vẫn mở được và giúp cả hai hình '
                     'dung hướng đi. Nhưng bản đồ ấy không biết con đường trước mặt vừa xảy ra chuyện gì. Đây là '
                     'khác biệt giữa thông tin được lưu sẵn và thông tin đang cập nhật. Dùng được ngoại tuyến rất '
                     'hữu ích, miễn là mình hiểu giới hạn của nó.'},
            {'key': 'directions',
             'bg': 'street',
             'kind': 'directions',
             'mood': 'curious',
             'label': 'Anh chỉ giúp đường nhé?',
             'text': 'Đến một ngã rẽ, Minh dừng lại hỏi bác bán hàng. Bác chỉ tay về phía con phố có hàng cây, '
                     'rồi nhắc cậu tránh một đoạn đang sửa. Không có giọng máy nào nói hãy rẽ phải sau hai trăm '
                     'mét. Đổi lại, Minh nhận được một chỉ dẫn mà người sống ngay tại đó biết rất rõ. Cậu nhắc '
                     'lại đường đi để chắc mình đã hiểu.'},
            {'key': 'commute',
             'bg': 'street',
             'kind': 'walk',
             'mood': 'happy',
             'label': 'Nhìn đường, hỏi người',
             'text': 'Quãng đường không bỗng trở nên dễ dàng hay lãng mạn. Minh mất thêm thời gian vì phải hỏi và '
                     'kiểm tra. Nhưng cậu cũng bắt đầu nhớ những mốc mà trước đây chỉ lướt qua: cửa hàng màu '
                     'xanh, chiếc cầu nhỏ, hàng cây ở góc phố. Khi chỉ dẫn trên màn hình vắng mặt, sự chú ý phải '
                     'quay lại với môi trường xung quanh.'},
            {'key': 'arrival',
             'bg': 'office',
             'kind': 'arrival',
             'mood': 'worry',
             'label': 'Mạng công ty cũng vậy',
             'text': 'Đến văn phòng, Minh tưởng vấn đề khó nhất đã qua. Cậu mở máy tính và nhìn đồng nghiệp đang '
                     'ngồi trước những màn hình chờ giống hệt mình. Tin nhắn công việc chưa đến. Một tài liệu '
                     'trên đám mây không mở được. Cuộc họp trực tuyến cũng không vào được. Hóa ra, tìm được đường '
                     'đến công ty mới chỉ là phần đầu của việc đi làm hôm nay.'}]},
 {'id': '04',
  'title': 'Công việc phía sau màn hình',
  'beats': [{'key': 'cloud',
             'bg': 'office',
             'kind': 'cloud',
             'mood': 'worry',
             'label': 'Tệp ở đâu?',
             'text': 'Minh phải hoàn thành một bản thuyết trình. Cậu nhớ tên tệp, nhớ cả màu biểu tượng, nhưng '
                     'không có bản sao trong máy. Những lần trước, tài liệu luôn hiện ra sau một cú bấm. Hôm nay, '
                     'câu hỏi rất cụ thể: dữ liệu ở trên thiết bị của mình, hay ở một hệ thống phải kết nối mới '
                     'tới được?'},
            {'key': 'local',
             'bg': 'office',
             'kind': 'local',
             'mood': 'happy',
             'label': 'Bản sao trong máy',
             'text': 'Linh, người ngồi cạnh, tìm thấy một bản tải xuống từ hôm trước. Cả nhóm mở tệp và tiếp tục '
                     'sửa. Nó có thể thiếu những thay đổi mới nhất, nên mọi người ghi rõ phiên bản đang dùng. Bản '
                     'sao ấy không giải quyết tất cả, nhưng tạo ra một điểm bắt đầu, thay vì để buổi sáng trôi '
                     'qua trước màn hình đang tải.'},
            {'key': 'lan',
             'bg': None,
             'kind': 'lan',
             'mood': 'curious',
             'label': 'Mạng nội bộ',
             'text': 'Hệ thống mạng bên trong văn phòng vẫn hoạt động trong giả định của chúng ta. Một số máy có '
                     'thể trao đổi tệp qua mạng nội bộ, và chiếc máy in vẫn nhận được lệnh. Khả năng ấy còn tùy '
                     'cách từng nơi thiết kế hệ thống. Điều quan trọng là Internet công cộng và mọi mạng máy tính '
                     'không phải cùng một thứ, nên mức ảnh hưởng cũng không thể giống hệt nhau.'},
            {'key': 'backup',
             'bg': 'office',
             'kind': 'backup',
             'mood': 'think',
             'label': 'Sao lưu • Quyền truy cập',
             'text': 'Cả nhóm phân loại: việc nào cần dữ liệu mới, việc nào làm được với tài liệu đang có, việc '
                     'nào nên chờ. Họ cũng tránh chép bừa dữ liệu công ty sang thiết bị không được phép. Làm việc '
                     'dự phòng vẫn cần giữ quyền truy cập và an toàn thông tin. Sự cố kết nối không làm những '
                     'trách nhiệm ấy biến mất.'},
            {'key': 'team',
             'bg': 'board-room',
             'kind': 'team',
             'mood': 'happy',
             'label': 'Việc làm được hôm nay',
             'text': 'Trên bảng, Minh viết ba việc mà nhóm có thể hoàn thành ngay. Một bản nháp được soát lại. '
                     'Một phương án được trao đổi trực tiếp. Vài quyết định được ghi thành biên bản để nhập vào '
                     'hệ thống sau. Năng suất vẫn bị ảnh hưởng, nhưng mọi người đã chuyển từ chờ mạng trở lại '
                     'sang chọn việc phù hợp với điều kiện đang có. Trước giờ ăn trưa, họ đã có thứ để bàn '
                     'giao.'}]},
 {'id': '05',
  'title': 'Một mã QR không đủ để trả tiền',
  'beats': [{'key': 'qr',
             'bg': 'shop',
             'kind': 'qr',
             'mood': 'worry',
             'label': 'Chờ xác nhận',
             'text': 'Buổi trưa, Minh ghé cửa hàng. Mã QR vẫn rõ ràng ở quầy. Camera vẫn nhận ra nó. Nhưng đọc '
                     'được mã và hoàn tất giao dịch là hai bước khác nhau. Ứng dụng của Minh không gửi được yêu '
                     'cầu qua kết nối đang gián đoạn. Cậu nhìn chủ cửa hàng; chủ cửa hàng nhìn màn hình chưa có '
                     'xác nhận.'},
            {'key': 'cash',
             'bg': 'shop',
             'kind': 'cash',
             'mood': 'happy',
             'label': 'Một cách thanh toán khác',
             'text': 'Minh tìm trong ví và có đủ tiền mặt. Việc mua hàng tiếp tục bằng một cách khác. Tiền mặt '
                     'cũng cần có sẵn, cần tiền trả lại và cần giữ cẩn thận. Tình huống không chứng minh một '
                     'phương thức luôn tốt hơn phương thức kia. Nó cho thấy một lựa chọn dự phòng có thể giúp '
                     'giao dịch nhỏ không mắc kẹt.'},
            {'key': 'card',
             'bg': None,
             'kind': 'card',
             'mood': 'think',
             'label': 'Tùy hệ thống',
             'text': 'Vậy mọi máy quẹt thẻ và cây rút tiền đều ngừng hoạt động sao? Không thể kết luận như vậy. '
                     'Chúng có thể dùng những đường truyền và cơ chế xử lý khác nhau; một số giao dịch còn có khả '
                     'năng xử lý ngoại tuyến theo điều kiện cụ thể. Khách hàng vẫn cần làm theo hướng dẫn của '
                     'ngân hàng và cửa hàng. Không nên đoán giao dịch thành công chỉ vì mình vừa bấm xong.'},
            {'key': 'ledger',
             'bg': 'shop',
             'kind': 'ledger',
             'mood': 'curious',
             'label': 'Ghi lại để đối chiếu',
             'text': 'Chủ cửa hàng dùng sổ ghi những khoản cần theo dõi. Khi hệ thống trở lại, giao dịch đang chờ '
                     'phải được kiểm tra trước khi thử thêm lần nữa. Màn hình quay mãi không chứng minh tiền đã '
                     'mất, cũng không chứng minh tiền đã tới. Trong lúc thông tin bị trễ, ghi chép rõ và xác nhận '
                     'đúng nguồn rất quan trọng.'},
            {'key': 'stock',
             'bg': 'shop',
             'kind': 'stock',
             'mood': 'worry',
             'label': 'Đặt hàng bị chậm',
             'text': 'Bữa trưa của Minh vẫn mua được. Nhưng phía sau cửa hàng còn có những việc khó nhìn thấy '
                     'hơn: cập nhật tồn kho, gửi đơn cho nhà cung cấp, xác nhận lịch giao. Nếu những bước ấy phụ '
                     'thuộc vào các dịch vụ đang gián đoạn, chúng sẽ chậm lại. Kệ hàng không tự trống ngay lập '
                     'tức. Rắc rối thường bắt đầu từ những thông tin không đến được đúng người, đúng lúc.'}]},
 {'id': '06',
  'title': 'Những kết nối phía sau thành phố',
  'beats': [{'key': 'web',
             'bg': None,
             'kind': 'web',
             'mood': 'curious',
             'label': 'Mạng của các mạng',
             'text': 'Internet không nằm trong một chiếc hộp mà ai đó có thể rút phích cắm. Nó nối rất nhiều '
                     'mạng, thiết bị và tổ chức. Một sự cố thực tế có thể ảnh hưởng từng khu vực, từng dịch vụ '
                     'khác nhau. Ở đây, ta gom sự gián đoạn thành một ngày giả tưởng để nhìn ra những mắt xích '
                     'thường bị che khuất.'},
            {'key': 'queue',
             'bg': None,
             'kind': 'queue',
             'mood': 'think',
             'label': 'Yêu cầu đang chờ',
             'text': 'Một đơn hàng chưa gửi, một thay đổi chưa đồng bộ, một cuộc hẹn chưa xác nhận. Từng việc có '
                     'vẻ nhỏ, nhưng khi nhiều việc cùng chậm, người phía sau phải chờ người phía trước. Hệ thống '
                     'có hàng đợi và phương án dự phòng sẽ ứng phó khác nhau. Những lựa chọn thiết kế ấy chỉ thật '
                     'sự lộ rõ khi đường đi quen thuộc gặp trục trặc.'},
            {'key': 'power',
             'bg': None,
             'kind': 'power',
             'mood': 'curious',
             'label': 'Mất mạng ≠ mất điện',
             'text': 'Đèn ngoài phố vẫn sáng. Mất Internet không tự động khiến cả lưới điện và hệ thống nước dừng '
                     'lại. Chúng có mạng điều khiển, quy trình vận hành và mức dự phòng riêng. Những phần phụ '
                     'thuộc kết nối vẫn có thể gặp khó khăn. Ta phải nhìn vào từng hệ thống, thay vì suy ra mọi '
                     'thứ từ chiếc điện thoại.'},
            {'key': 'care',
             'bg': None,
             'kind': 'care',
             'mood': 'neutral',
             'label': 'Thiết bị • Hồ sơ • Liên lạc',
             'text': 'Trong cơ sở y tế, thiết bị đo tại chỗ và dịch vụ tra cứu hồ sơ từ xa có thể chịu tác động '
                     'khác nhau. Nhân viên sẽ làm theo phương án dự phòng của nơi đó. Một ứng dụng bị lỗi không '
                     'có nghĩa mọi chăm sóc đều ngừng. Điều cần quan tâm là khả năng duy trì phần thiết yếu khi '
                     'kết nối quen thuộc không sẵn có.'},
            {'key': 'truck',
             'bg': 'street',
             'kind': 'truck',
             'mood': 'think',
             'label': 'Xe chạy, thông tin chậm',
             'text': 'Chiếc xe giao hàng vẫn có động cơ, bánh xe và người lái. Nhưng tài xế có thể thiếu một địa '
                     'chỉ mới cập nhật, một xác nhận từ kho hoặc thông tin từ người nhận. Minh bắt đầu nhìn thành '
                     'phố theo cách khác: nhiều hoạt động vật lý vẫn tiếp tục, trong khi lớp thông tin điều phối '
                     'chúng đang chậm lại. Sự phụ thuộc không chỉ nằm ở những phút mình lướt điện thoại.'}]},
 {'id': '07',
  'title': 'Thích nghi với một buổi tối khác',
  'beats': [{'key': 'cafe',
             'bg': 'cafe',
             'kind': 'cafe',
             'mood': 'curious',
             'label': 'Một buổi tối khác',
             'text': 'Chiều xuống, Minh ghé quán quen. Mật khẩu Wi-Fi không giúp ai mở thêm trang web. Có người '
                     'trò chuyện, có người sốt ruột vì việc chưa xong. Mất kết nối không tạo ra cùng một trải '
                     'nghiệm. Với người này là khoảng nghỉ; với người khác là thu nhập hoặc cuộc hẹn quan trọng. '
                     'Minh hiểu rằng ngày hôm nay của mình chỉ là một lát cắt.'},
            {'key': 'meet',
             'bg': 'cafe',
             'kind': 'meet',
             'mood': 'happy',
             'label': 'Gặp nhau trực tiếp',
             'text': 'Minh gặp Linh theo giờ đã hẹn. Họ mất vài phút để chắc không ai đang chờ thêm tin nhắn xác '
                     'nhận. Rồi cả hai mở sổ, bàn tiếp việc ở công ty. Cuộc gặp có một lợi thế giản dị: người cần '
                     'nghe đang ngồi trước mặt, và có thể hỏi lại ngay khi chưa hiểu. Những câu hỏi trên giấy lần '
                     'lượt có câu trả lời.'},
            {'key': 'offlinework',
             'bg': 'board-room',
             'kind': 'offline-work',
             'mood': 'happy',
             'label': 'Làm phần có thể làm',
             'text': 'Về nhà, Minh soát bản nháp đã mang về theo cách công ty cho phép. Cậu ghi câu hỏi cho ngày '
                     'mai và đánh dấu phần thiếu dữ liệu. Cậu vẫn phân tâm, vẫn có lúc muốn mở điện thoại. Chỉ là '
                     'hôm nay, mỗi lần mở lên, cậu nhớ mình đang tìm điều gì. Một việc cụ thể dần được hoàn thành '
                     'trước khi cậu chuyển sang việc khác.'},
            {'key': 'kit',
             'bg': None,
             'kind': 'kit',
             'mood': 'think',
             'label': 'Chuẩn bị từ trước',
             'text': 'Minh ghi danh sách cho lần sau: số liên hệ quan trọng, bản đồ ngoại tuyến, bản sao tài liệu '
                     'được phép lưu và một cách thanh toán khác phù hợp. Những thứ ấy cần chuẩn bị trước sự cố. '
                     'Chúng không bảo đảm ngày nào cũng thuận lợi, nhưng có thể giảm vài điểm phụ thuộc. Cậu '
                     'khoanh tròn một việc nhỏ mà mình có thể chuẩn bị ngay.'},
            {'key': 'calm',
             'bg': 'home-night',
             'kind': 'calm',
             'mood': 'happy',
             'label': 'Biết mình đang cần gì',
             'text': 'Sau bữa tối, Minh đặt điện thoại xuống, đọc vài trang sách. Ngoài kia vẫn có người đang xử '
                     'lý những việc nghiêm túc vì sự cố. Với riêng cậu, khoảng lặng giúp phân biệt rõ hơn giữa '
                     'một kết nối phục vụ công việc và một lần mở ứng dụng vì thói quen. Cậu đánh dấu trang sách, '
                     'rồi chuẩn bị cho buổi sáng tiếp theo.'}]},
 {'id': '08',
  'title': 'Khi Internet trở lại',
  'beats': [{'key': 'return',
             'bg': 'home',
             'kind': 'return',
             'mood': 'curious',
             'label': 'Sáng hôm sau',
             'text': 'Sáng hôm sau, trong câu chuyện giả tưởng, kết nối dần trở lại. Một số dịch vụ mở được '
                     'trước; số khác cần thêm thời gian. Minh chỉ thấy từng phần quen thuộc lần lượt trở về: một '
                     'trang tải xong, một cuộc trao đổi tiếp tục, một dữ liệu bắt đầu đồng bộ. Không phải mọi thứ '
                     'đều hoàn tất ngay trong cùng một khoảnh khắc.'},
            {'key': 'messages',
             'bg': 'home',
             'kind': 'messages',
             'mood': 'worry',
             'label': 'Thông báo trở lại',
             'text': 'Điện thoại rung liên tiếp. Minh vui vì liên lạc đã thông, rồi thấy hàng đợi mới: tin nhắn, '
                     'lời nhắc và việc chưa xong. Mạng trở lại không khiến công việc tồn đọng tự biến mất. Nhiều '
                     'người và hệ thống vẫn phải đối chiếu, xác nhận, xử lý những gì bị dồn lại. Cậu hít một hơi, '
                     'chọn xem việc quan trọng trước.'},
            {'key': 'reconcile',
             'bg': 'office',
             'kind': 'reconcile',
             'mood': 'think',
             'label': 'Kiểm tra trước khi gửi lại',
             'text': 'Ở công ty, Minh và Linh kiểm tra bản nháp nào đã sửa, thay đổi nào cần nhập lại và việc nào '
                     'đã xong. Khoản thanh toán còn nghi ngờ cũng cần xác nhận qua kênh chính thức trước khi thử '
                     'lại. Sau một ngày thiếu thông tin, vội vàng có thể tạo thêm lỗi. Cả nhóm dành thời gian để '
                     'khôi phục một trạng thái cùng hiểu đúng.'},
            {'key': 'choice',
             'bg': 'board-room',
             'kind': 'choice',
             'mood': 'happy',
             'label': 'Dùng có chủ đích',
             'text': 'Minh vẫn dùng bản đồ, nhắn tin và làm việc trên mạng. Cậu chỉ thêm vài lựa chọn: lưu thứ '
                     'cần thiết theo đúng quyền hạn, nhớ số liên hệ, hiểu dữ liệu nằm ở đâu và chừa thời gian tập '
                     'trung. Công nghệ tiếp tục giúp cậu. Cậu cũng hiểu rõ hơn mình đang phụ thuộc vào điều gì, '
                     'và có thể chuẩn bị gì từ hôm nay.'},
            {'key': 'end',
             'bg': 'street',
             'kind': 'end',
             'mood': 'happy',
             'label': 'Bạn sẽ vướng ở đâu đầu tiên?',
             'text': 'Nếu Internet biến mất trong hai mươi bốn giờ, rắc rối đầu tiên của bạn sẽ nằm ở đâu: tìm '
                     'đường, công việc, thanh toán, hay liên lạc với một người quan trọng? Hãy nghĩ đến một việc '
                     'cụ thể, rồi tự hỏi mình có phương án nào khác. Với Minh, câu trả lời bắt đầu từ một tờ giấy '
                     'rất nhỏ trong túi áo. Một ngày mất kết nối đã giúp cậu nhìn rõ hơn những kết nối mà mình '
                     'muốn giữ.'}]}]
