INK='#29231F'; PAPER='#FFF8E8'; RED='#B84132'; GREEN='#497052'

def actor(name, x, y, scale=1, mood='curious', pose='stand'):
    arms = {'stand': ('M0 123 Q-70 190 -120 270', 'M0 123 Q65 198 110 270'), 'shrug': ('M0 123 Q-85 174 -160 110', 'M0 123 Q80 172 156 108'), 'scratch': ('M0 123 Q-70 190 -120 270', 'M0 123 Q125 93 82 -20'), 'point': ('M0 123 Q-70 190 -120 270', 'M0 123 Q100 158 225 110'), 'leftpoint': ('M0 123 Q-140 60 -320 -2', 'M0 123 Q70 196 110 270'), 'reach': ('M0 123 Q-70 190 -120 270', 'M0 123 Q120 140 250 135'), 'happy': ('M0 123 Q-105 50 -155 -38', 'M0 123 Q95 55 150 -28'), 'think': ('M0 123 Q-70 190 -120 270', 'M0 123 Q140 145 50 65')}
    arms.update({
        'phone': ('M0 123 Q-70 190 -120 270', 'M0 123 Q92 155 132 110'),
        'read': ('M0 123 Q-75 175 -28 195', 'M0 123 Q87 172 54 195'),
        'call': ('M0 123 Q-70 190 -120 270', 'M0 123 Q130 70 91 2'),
        'carry': ('M0 123 Q-70 190 -120 270', 'M0 123 Q95 198 153 235'),
        'write': ('M0 123 Q-70 190 -120 270', 'M0 123 Q130 154 220 110'),
    })
    left, right = arms[pose]
    mouth = {'curious': 'M-12 49 Q2 39 18 46', 'worry': 'M-25 54 Q0 31 28 53', 'happy': 'M-30 34 Q0 67 34 33', 'neutral': 'M-19 43 Q1 44 21 41'}[mood]
    brows = ('M-51 -46 Q-31 -51 -12 -42', 'M16 -43 Q35 -57 56 -58') if mood in ['curious', 'worry'] else ('M-52 -44 Q-29 -53 -12 -42', 'M16 -43 Q36 -54 58 -43')
    return f'<g transform="translate({x} {y}) scale({scale})"><ellipse cx="0" cy="504" rx="115" ry="15" fill="#5B4027" opacity=".12"/><g id="{name}" class="actor">\n <g class="ink limbs"><path class="torso" d="M0 91 Q-7 211 0 319"/><path class="leg-left" d="M0 319 Q-40 419 -87 497"/><path class="leg-right" d="M0 319 Q43 416 91 498"/>\n <path class="arm-left" d="{left}"/><path class="arm-right" d="{right}"/></g>\n <g class="actor-head"><path d="M-91 -4 C-94 -58 -53 -91 -4 -94 C52 -98 94 -57 94 -5 C96 50 61 89 6 93 C-48 94 -89 54 -91 -4Z" fill="#FFFDF9" stroke="{INK}" stroke-width="6"/>\n <path d="M-83 -8 C-89 -57 -49 -85 -4 -87" stroke="#837B72" opacity=".2" stroke-width="2" fill="none"/>\n <g class="eyes" fill="#FFFDF9" stroke="{INK}" stroke-width="3"><ellipse cx="-33" cy="-7" rx="18" ry="22"/><ellipse cx="34" cy="-9" rx="18" ry="23"/><g class="pupils" fill="{INK}" stroke="none"><ellipse cx="-29" cy="-3" rx="7" ry="10"/><ellipse cx="39" cy="-6" rx="7" ry="10"/></g></g>\n <g class="ink fine"><path class="brow-left" d="{brows[0]}"/><path class="brow-right" d="{brows[1]}"/><path class="mouth" d="{mouth}"/></g>\n </g></g></g>'

def paper(x, y, w, h, name, content, fill='#FFFDF4'):
    return f'<g transform="translate({x} {y})"><g id="{name}" class="prop"><path d="M4 10 Q{w * 0.45} -3 {w - 8} 5 L{w - 1} {h - 9} Q{w * 0.4} {h + 4} 4 {h - 2}Z" fill="{fill}" stroke="{INK}" stroke-width="4"/><path d="M14 {h - 16}L{w - 15} {h - 22}" stroke="#B8A88A" stroke-width="2" opacity=".5"/>{content}</g></g>'

def text(x, y, label, size=52, fill=INK):
    return f'<text x="{x}" y="{y}" font-size="{size}" style="fill:{fill}">{label}</text>'

def bubble(x, y, name, title, number='?%'):
    return f'<g transform="translate({x} {y})"><g id="{name}" class="prop"><path d="M15 55 Q-4 3 83 12 Q191 -17 288 7 Q408 -10 450 34 Q547 12 569 74 Q624 119 576 170 Q602 241 511 242 Q420 278 338 252 Q238 279 168 248 Q70 267 48 211 Q-21 201 13 146 Q-25 90 15 55Z" fill="#FFFDF4" stroke="{INK}" stroke-width="5"/><ellipse cx="57" cy="307" rx="24" ry="18" fill="#FFFDF4" stroke="{INK}" stroke-width="4"/><ellipse cx="22" cy="349" rx="11" ry="9" fill="#FFFDF4" stroke="{INK}" stroke-width="3"/>{text(67, 77, title, 40)}{text(182, 212, number, 140, RED)}</g></g>'
