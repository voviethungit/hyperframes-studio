const fs=require('node:fs');
const puppeteer=require('/workspace/.onboarding/hyperframes-tools/node_modules/puppeteer-core');
(async()=>{
 const shots=JSON.parse(fs.readFileSync('timeline.json','utf8')).shots;
 const browser=await puppeteer.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const page=await browser.newPage();await page.setViewport({width:1920,height:1080});
  await page.goto('http://127.0.0.1:3007/api/projects/internet-24h/preview',{waitUntil:'networkidle0'});
  const report=await page.evaluate(shots=>{
   const regs=window.__timelines, checks=[];
   const inventory=shots.map(s=>({id:s.id,tweens:regs[s.id]?.getChildren(true,true,true).length||0}));
   for(const id of ['s03','s08','s16','s22','s39']){
    const s=shots.find(s=>s.id===id),tl=regs[id];
    const side=(s.bg==='board-room'||s.kind==='call')?'left':'right';
    const arm=document.querySelector('#'+id+'-minh .arm-'+side);
    tl.seek(1,false);const before=arm.getAttribute('d');
    tl.seek(s.duration*.44+.7,false);const after=arm.getAttribute('d');
    checks.push({kind:'arm',id,changed:before!==after,before,after});
   }
   const eyes=document.querySelector('#s01-minh .eyes');
   regs.s01.seek(1,false);const open=gsap.getProperty(eyes,'scaleY');
   regs.s01.seek(1.47,false);const blink=gsap.getProperty(eyes,'scaleY');
   checks.push({kind:'blink',id:'s01',open,blink,changed:open-blink>.5});
   const walker=document.querySelector('#s14-minh');
   regs.s14.seek(1,false);const startX=gsap.getProperty(walker,'x');
   regs.s14.seek(6,false);const endX=gsap.getProperty(walker,'x');
   checks.push({kind:'walk',id:'s14',startX,endX,changed:endX-startX>200});
   const truck=document.querySelector('#s30-truck');
   regs.s30.seek(1.5,false);const truckStart=gsap.getProperty(truck,'x');
   regs.s30.seek(7,false);const truckEnd=gsap.getProperty(truck,'x');
   checks.push({kind:'truck',id:'s30',truckStart,truckEnd,changed:Math.abs(truckEnd-truckStart)>150});
   return {inventory,checks,registered:Object.keys(regs).length};
  },shots);
  fs.writeFileSync('renders/motion-verification.json',JSON.stringify(report,null,2));
  if(report.inventory.some(x=>x.tweens<6)||report.checks.some(x=>!x.changed))throw Error('Motion verification failed');
  console.log(JSON.stringify({shots:report.inventory.length,checks:report.checks.length,allPassed:true}));
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
