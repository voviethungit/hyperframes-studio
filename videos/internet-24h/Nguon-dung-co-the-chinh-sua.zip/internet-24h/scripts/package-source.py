"""Preserve only the editable original project, never recordings or user uploads."""
from pathlib import Path
import zipfile
P=Path(__file__).resolve().parents[1]
files=[]
for name in ['story.py','README.md','DESIGN.md','SPEC.md','REVIEW.md','index.html','hyperframes.json','meta.json','package.json','timeline.json']:
 files.append(P/name)
files.extend(sorted((P/'compositions').glob('*.html')))
files.extend(sorted((P/'scripts').glob('*.py')))
files.extend(sorted((P/'scripts').glob('*.cjs')))
files.extend(sorted((P/'assets/fonts').glob('*')))
files.extend(sorted((P/'assets/backgrounds').glob('*.webp')))
files.extend([P/'assets/gsap.min.js',P/'assets/manifest.json'])
out=P/'delivery/Nguon-dung-co-the-chinh-sua.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:
  if f.is_file():z.write(f,Path('internet-24h')/f.relative_to(P))
print(f'Packed {len(files)} source files, {out.stat().st_size} bytes; no audio, private uploads, caches or render frames included.')
