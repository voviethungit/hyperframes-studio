from pathlib import Path
import sys, json, re, math, html
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from story import CHAPTERS
from rig import actor,paper,text,INK,PAPER,RED,GREEN

P=Path(__file__).resolve().parents[1]
fonts=(P/'assets/fonts/local.css').read_text()
CSS='''
*{box-sizing:border-box}#root{position:absolute;inset:0;overflow:hidden;font-family:'Be Vietnam Pro';color:#29231F}.stage,.camera{position:absolute;inset:0}.stage{background:#FFF8E8}.camera{transform-origin:50% 65%}.bg,.art{position:absolute;inset:0;width:1920px;height:1080px}.bg{object-fit:cover}.art{overflow:visible}
svg text{font-family:'Be Vietnam Pro';font-weight:800;fill:#29231F}.ink{stroke:#29231F;stroke-width:7;fill:none;stroke-linecap:round;stroke-linejoin:round}.fine{stroke-width:3.5}.eyes{transform-box:fill-box;transform-origin:center}.actor-head{transform-box:fill-box;transform-origin:50% 65%}.prop{transform-box:fill-box;transform-origin:center}.line-draw{stroke-linecap:round;stroke-linejoin:round}.spinner{transform-box:fill-box;transform-origin:center}
'''

def group(id,content,x=0,y=0,scale=1):
 return f'<g transform="translate({x} {y}) scale({scale})"><g id="{id}" class="prop">{content}</g></g>'

def label(id,words,x=1110,y=135,w=650,fill='#FFFDF4',size=None):
 fs=size or max(34,min(53,round((w-80)/(max(1,len(words))*.59))))
 return paper(x,y,w,116,id,text(38,76,html.escape(words),fs),fill)

def phone(id,x,y,w=200,h=350,good=False,lines=True):
 linecolor=GREEN if good else '#8E8C82'
 body=f'<rect x="0" y="0" width="{w}" height="{h}" rx="{w*.12}" fill="#DDD6C8" stroke="{INK}" stroke-width="6"/><rect x="{w*.08}" y="{h*.1}" width="{w*.84}" height="{h*.77}" rx="10" fill="#E4F0E9" stroke="{INK}" stroke-width="3"/><path d="M{w*.39} {h*.05}H{w*.61}" stroke="{INK}" stroke-width="4" stroke-linecap="round"/><circle cx="{w*.5}" cy="{h*.94}" r="{w*.035}" fill="none" stroke="{INK}" stroke-width="3"/>'
 if good: body+=f'<path d="M{w*.25} {h*.47}L{w*.44} {h*.6}L{w*.76} {h*.34}" stroke="{GREEN}" stroke-width="10" fill="none" stroke-linecap="round"/>'
 else:
  body+='<g>'+''.join(f'<circle class="pending-dot" cx="{w*f}" cy="{h*.47}" r="{w*.045}" fill="{RED}"/>' for f in [.32,.5,.68])+'</g>'
 if lines:body+=f'<path d="M{w*.22} {h*.73}H{w*.78}" stroke="{linecolor}" stroke-width="5" stroke-linecap="round"/>'
 return group(id,body,x,y)

def wifi(id,x,y,color=INK,s=1):
 body=f'<g stroke="{color}" stroke-width="9" fill="none" stroke-linecap="round"><path d="M-90 0Q0 -75 90 0M-58 33Q0 -16 58 33M-27 64Q0 40 27 64"/></g><circle cy="94" r="9" fill="{color}"/>'
 return group(id,body,x,y,s)

def router(id,x,y):
 body=f'<path d="M26 89L4 -65M358 89L381 -65" class="ink"/><path d="M0 80Q192 61 400 80L392 190L7 185Z" fill="#DDD6C8" stroke="{INK}" stroke-width="6"/><path d="M20 104H376" class="ink fine"/>'
 for i in range(5):body+=f'<circle class="router-light" cx="{56+i*54}" cy="146" r="8" fill="{GREEN}"/>'
 return group(id,body,x,y)

def laptop(id,x=960,y=430,w=580):
 body=f'<path d="M30 0Q{w*.5} -12 {w-10} 0L{w-34} 294L12 292Z" fill="#BCD5D4" stroke="{INK}" stroke-width="7"/><path d="M51 26H{w-37}L{w-55} 266H34Z" fill="#FFFDF4" stroke="{INK}" stroke-width="3"/><path d="M12 292L-64 353Q{w*.5} 374 {w+58} 350L{w-34} 294Z" fill="#C6BDAA" stroke="{INK}" stroke-width="6"/>'
 return group(id,body,x,y)

def folder(id,x,y,word='Tài liệu',good=True):
 body=f'<path d="M0 50V-15H130L164 25H388V250H0Z" fill="#E9C98E" stroke="{INK}" stroke-width="5"/><path d="M0 59L418 47L386 255L0 250Z" fill="#F5DCAB" stroke="{INK}" stroke-width="5"/>{text(33,160,word,44)}'
 if good:body+=f'<path d="M260 184L284 209L334 153" stroke="{GREEN}" stroke-width="8" fill="none" stroke-linecap="round"/>'
 return group(id,body,x,y)

def cloud(id,x,y,word='Đám mây',broken=True):
 body=f'<path d="M28 125Q-18 70 54 40Q75 -36 152 12Q218 -26 250 43Q329 32 325 113Q354 179 283 186H70Q-10 182 28 125Z" fill="#E4ECE9" stroke="{INK}" stroke-width="6"/>{text(53,111,word,41)}'
 if broken:body+=f'<path d="M118 232L190 290M190 232L118 290" stroke="{RED}" stroke-width="11" stroke-linecap="round"/>'
 return group(id,body,x,y)

def map_prop(id,x=1080,y=350,word='Đã lưu'):
 body=f'<path d="M0 25L160 0L325 23L496 -2V352L325 378L160 354L0 377Z" fill="#F7EBD1" stroke="{INK}" stroke-width="5"/><path d="M160 0V354M325 23V378" stroke="#B49D78" stroke-width="3"/>'
 body+='<g fill="none" stroke="#B7CBA4" stroke-width="16"><path d="M24 82L450 291M40 302L460 75M92 32L94 350M400 25L405 340"/></g>'
 body+=f'<path class="route line-draw" d="M80 282L188 198L283 243L396 124" fill="none" stroke="{GREEN}" stroke-width="9" stroke-dasharray="10 10"/><path d="M396 62C345 62 346 117 396 158C447 117 448 62 396 62Z" fill="{RED}" stroke="{INK}" stroke-width="3"/><circle cx="396" cy="92" r="10" fill="#FFFDF4"/>{text(27,335,word,37)}'
 return group(id,body,x,y)

def notebook(id,x=1110,y=360,words=('Ghi chú','Việc cần làm')):
 body=f'<path d="M0 0Q220 -14 460 0L451 405Q220 419 3 405Z" fill="#FFFDF4" stroke="{INK}" stroke-width="5"/><path d="M43 0V405" stroke="#B18C66" stroke-width="3"/>'
 for i in range(6):body+=f'<path d="M18 {35+i*60}H-10" class="ink fine"/>'
 for i,word in enumerate(words):body+=text(71,77+i*84,word,max(31,min(43,round(325/(len(word)*.57)))))
 return group(id,body,x,y)

def envelope(id,x,y,good=False,scale=1):
 body=f'<path d="M0 0H230V142H0Z" fill="#FFFDF4" stroke="{INK}" stroke-width="4"/><path d="M0 0L115 86L230 0M0 142L83 64M230 142L148 64" class="ink fine"/>'
 if good:body+=f'<circle cx="221" cy="0" r="31" fill="#E3EDDC" stroke="{INK}" stroke-width="3"/><path d="M207 0L220 12L238 -12" stroke="{GREEN}" stroke-width="5" fill="none"/>'
 return group(id,body,x,y,scale)

def money(id,x=1130,y=470):
 body=f'<path d="M0 25L372 0L388 173L15 202Z" fill="#D5E1B2" stroke="{INK}" stroke-width="5"/><path d="M25 47L349 25L361 151L38 176Z" fill="none" stroke="#6D8557" stroke-width="3"/><ellipse cx="192" cy="102" rx="62" ry="54" fill="none" stroke="#6D8557" stroke-width="4"/>{text(129,117,'Tiền',37)}'
 return group(id,body,x,y)

def clock(id,x,y,hour=7):
 a=(hour%12)*math.pi/6
 body=f'<circle r="107" fill="#F7E9CB" stroke="{INK}" stroke-width="7"/><circle r="91" fill="none" stroke="#B28E5C" stroke-width="3"/><path d="M0 0V-72M0 0L{math.sin(a)*54:.2f} {-math.cos(a)*54:.2f}" class="ink"/><circle r="7" fill="{INK}"/>'
 for i in range(12):
  a=i*math.pi/6;body+=f'<path d="M{math.sin(a)*78:.1f} {-math.cos(a)*78:.1f}L{math.sin(a)*85:.1f} {-math.cos(a)*85:.1f}" class="ink fine"/>'
 return group(id,body,x,y)

def chair(x,y):
 return f'<path d="M{x-72} {y-230}L{x-72} {y-10}H{x+65}V{y-220}M{x-60} {y-10}L{x-82} {y+145}M{x+55} {y-10}L{x+78} {y+145}" fill="none" stroke="#755334" stroke-width="8" stroke-linecap="round"/>'

def design(b,ident,slot):
 """Return an original shot with semantic props and deterministic acting cues."""
 key=b['key'];kind=b['kind'];a=ident+'-minh';other=ident+'-linh';bg=b['bg']
 mood=b['mood'] if b['mood']!='think' else 'curious'
 cutaway=not bg
 x=530 if cutaway else (650 if bg in ['street','shop'] else 810)
 y=400; scale=1
 pose='phone' if kind in ['phone','refresh','offline-phone','return','messages','qr','ride'] else ('call' if kind=='call' else ('think' if b['mood']=='think' else 'stand'))
 if kind in ['address','local','ledger','offline-work','calm','map']:pose='read'
 if kind in ['router','network','gps','lan','web','power','care','backup','queue','stock','team','choice','kit','card']:pose='point'
 if bg=='board-room':x=1065;pose='leftpoint'
 if kind in ['talk','directions','meet']:x=610
 arts=[];anim=[];reveals=[]
 def add(content,pid=None,when=.5):
  arts.append(content)
  if pid:reveals.append((pid,when))
 def lab(words=None,lx=None,ly=140,w=650):
  pid=ident+'-label';add(label(pid,words or b['label'],lx if lx is not None else (160 if bg=='shop' else 1110),ly,w),pid,.45)
 def note(words,px=1110,py=390):
  pid=ident+'-note';add(notebook(pid,px,py,words),pid,slot*.3)
 def phone_hero(good=False):
  pid=ident+'-phone';add(phone(pid,1150,355,210,370,good),pid,.7)
  add(phone(ident+'-held',x+98,y+28,76,133,good,False))
  return pid
 def other_actor(px=1150,py=400,s=.95,pose='shrug'):
  art=actor(other,px,py,s,'happy' if key not in ['neighbour'] else 'curious',pose)
  # A small distinct hair tuft keeps the colleague recognisable across scenes.
  art+=f'<path d="M{px-45*s} {py-82*s}q{10*s} {-39*s} {32*s} {-19*s}q{20*s} {-23*s} {35*s} {0*s}" fill="none" stroke="#5C4030" stroke-width="7" stroke-linecap="round"/>'
  add(art)

 # The shopkeeper's lower body stays behind the illustrated counter.
 if bg=='shop':
  clerk=actor(ident+'-clerk',1515,285,.76,'happy','stand')
  arts.append(f'<defs><clipPath id="{ident}-counter-clip"><rect x="1200" y="130" width="650" height="355"/></clipPath></defs><g clip-path="url(#{ident}-counter-clip)">{clerk}</g>')
 # Actors are behind hand-held foreground props and front of environmental art.
 if kind=='meet':
  arts.append(chair(640,735)+chair(1280,735))
 main=actor(a,x,y,scale,mood,pose)
 if kind=='meet':
  main=main.replace('M0 319 Q-40 419 -87 497','M0 319 Q70 320 98 384 L98 497').replace('M0 319 Q43 416 91 498','M0 319 Q35 370 38 498')
 arts.append(main)

 if kind in ['phone','refresh','offline-phone','return','messages','qr','ride']:
  good=kind in ['offline-phone','return'];pid=phone_hero(good)
  lab()
  if key=='wake':
   add(label(ident+'-title','Nếu Internet biến mất',160,135,710,size=48),ident+'-title',.15)
   add(label(ident+'-title2','trong 24 giờ?',180,260,490,size=52),ident+'-title2',.75)
   add(clock(ident+'-clock',365,620,7),ident+'-clock',1.4)
  if kind=='refresh':
   anim.append(f"tl.to('#{a} .arm-right',{{attr:{{d:'M0 123 Q100 158 155 109'}},duration:.25,repeat:5,yoyo:true,ease:'sine.inOut'}},2);")
   add(wifi(ident+'-wifi',1570,490,RED,.7),ident+'-wifi',slot*.45)
  if kind=='offline-phone':
   for i,t in enumerate(['Ảnh đã chụp','Ghi chú','Nhạc đã lưu']):add(label(ident+'-offline'+str(i),t,1435,350+i*160,370,size=33),ident+'-offline'+str(i),2+i*2.1)
  if kind=='messages':
   for i in range(5):add(envelope(ident+'-env'+str(i),1080+(i%2)*320,290+i*104,True,.9),ident+'-env'+str(i),1.2+i*.8)
  if kind=='qr':
   add(label(ident+'-qr','QR',1525,630,230,size=62),ident+'-qr',2)
   # No fake transaction amount and no scannable payment code.
   add(label(ident+'-confirm','Chưa xác nhận',1140,805,530,size=40),ident+'-confirm',slot*.5)
  if kind=='ride':
   add(group(ident+'-car','<path d="M0 74L48 12H230L283 74H327V173H-18V88Z" fill="#D9C390" stroke="#29231F" stroke-width="5"/><circle cx="57" cy="175" r="35" fill="#706B60" stroke="#29231F" stroke-width="5"/><circle cx="252" cy="175" r="35" fill="#706B60" stroke="#29231F" stroke-width="5"/>',1440,675),ident+'-car',slot*.38)
  if kind=='return':
   add(wifi(ident+'-wifi',1570,490,GREEN,.7),ident+'-wifi',slot*.4)

 elif kind=='router':
  lab();add(router(ident+'-router',1120,555),ident+'-router',.7)
  add(wifi(ident+'-wifi',1360,340,GREEN),ident+'-wifi',1.6)
  add(cloud(ident+'-cloud',1510,570,'Internet'),ident+'-cloud',slot*.4)
  anim.append(f"tl.to('#{ident}-router .router-light',{{opacity:.25,duration:.35,stagger:.12,repeat:3,yoyo:true}},2);")

 elif kind in ['talk','directions','cafe','meet']:
  lab(lx=1050 if kind!='meet' else 1070,w=690)
  if kind!='cafe':other_actor(1230,400,.97,'point' if kind=='directions' else 'shrug')
  if kind=='directions':
   add(map_prop(ident+'-map',840,700,'Đường đi'),ident+'-map',slot*.43)
   anim.append(f"tl.to('#{other} .arm-right',{{attr:{{d:'M0 123 Q120 39 241 -52'}},duration:.65,ease:'power2.out'}},3);")
  if kind=='meet':
   # Foreground table covers the two characters' laps in a cafe conversation.
   add(group(ident+'-table','<ellipse cx="0" cy="0" rx="284" ry="60" fill="#D6AA6C" stroke="#29231F" stroke-width="5"/><path d="M-150 30L-175 325M150 30L175 325" stroke="#755334" stroke-width="9"/><path d="M-80 -50H32V16H-80Z" fill="#FFFDF4" stroke="#29231F" stroke-width="3"/>',960,675),ident+'-table',1.0)
  else:
   add(envelope(ident+'-talk',880,610,False,.75),ident+'-talk',slot*.5)

 elif kind=='premise':
  lab(lx=1000,w=740)
  add(clock(ident+'-time',1320,505,7),ident+'-time',.7)
  add(label(ident+'-hours','Một tình huống giả tưởng',1000,710,770,size=43),ident+'-hours',2.0)
  add(label(ident+'-power','Điện và mạng riêng: tùy hệ thống',270,887,1290,size=42),ident+'-power',slot*.5)

 elif kind=='network':
  lab(lx=1090,w=690)
  add(router(ident+'-router',930,510),ident+'-router',.8)
  add(cloud(ident+'-cloud',1470,420,'Internet'),ident+'-cloud',1.7)
  add(group(ident+'-links','<path d="M723 625H920M1340 625H1440" fill="none" stroke="#497052" stroke-width="8" stroke-dasharray="16 12"/><path d="M1370 594L1426 652M1426 594L1370 652" stroke="#B84132" stroke-width="10" stroke-linecap="round"/>'),ident+'-links',slot*.36)
  add(label(ident+'-near','Mạng gần',900,800,430,size=44),ident+'-near',slot*.5)

 elif kind=='call':
  lab();add(phone(ident+'-call',x+77,y-28,65,120,True,False))
  add(phone(ident+'-otherphone',1260,380,200,350,True),ident+'-otherphone',.7)
  add(wifi(ident+'-waves',1090,480,GREEN,.45),ident+'-waves',slot*.36)
  add(label(ident+'-caveat','Nếu mạng thoại còn hoạt động',1070,820,760,size=40),ident+'-caveat',slot*.6)

 elif kind in ['gps','map']:
  lab();add(map_prop(ident+'-map',1050,440,b['label'] if kind=='map' else 'Bản đồ'),ident+'-map',.9)
  if kind=='gps':
   add(group(ident+'-sat','<rect x="-60" y="-45" width="120" height="90" rx="12" fill="#C6DDE1" stroke="#29231F" stroke-width="5"/><path d="M-60 -35H-180V35H-60M60 -35H180V35H60" fill="#A6BFCA" stroke="#29231F" stroke-width="4"/><path d="M0 45L30 100" stroke="#29231F" stroke-width="4"/><path d="M-30 97Q30 145 67 84" fill="#E9C98E" stroke="#29231F" stroke-width="4"/>',1370,285),ident+'-sat',1.7)
  anim.append(f"tl.fromTo('#{ident}-map .route',{{strokeDasharray:600,strokeDashoffset:600}},{{strokeDashoffset:0,duration:3.5,ease:'none'}},2);")

 elif kind in ['address','local','ledger','offline-work','calm']:
  lab(lx=200 if bg=='board-room' else (160 if bg=='shop' else 1120),w=640)
  words={'address':('Địa chỉ','Số liên hệ'),'local':('Bản tải xuống','Kiểm tra phiên bản'),'ledger':('Đã xác nhận','Cần kiểm tra'),'offline-work':('Đã làm','Cần hỏi','Thiếu dữ liệu'),'calm':('Đọc vài trang','Nghỉ một chút')}[kind]
  nx=250 if bg=='board-room' else 1120
  note(words,nx,380)
  # A small held notebook follows the read pose in the actor's hands.
  add(group(ident+'-heldbook','<path d="M-75 0Q-18 -16 0 7Q35 -12 86 0V72Q25 63 0 80Q-30 61 -75 72Z" fill="#FFFDF4" stroke="#29231F" stroke-width="4"/><path d="M0 7V80" stroke="#29231F" stroke-width="3"/>',x+15,y+182))

 elif kind in ['walk','arrival']:
  lab(lx=1110)
  if kind=='walk':
   add(map_prop(ident+'-map',1170,400,'Mốc quen thuộc'),ident+'-map',1.2)
   anim.append(f"tl.fromTo('#{a}',{{x:-190}},{{x:150,duration:6,ease:'none'}},.4);")
   anim.append(f"tl.to('#{a} .leg-left',{{attr:{{d:'M0 319 Q42 417 91 497'}},duration:.45,repeat:11,yoyo:true,ease:'sine.inOut'}},.4);")
   anim.append(f"tl.to('#{a} .leg-right',{{attr:{{d:'M0 319 Q-40 417 -87 498'}},duration:.45,repeat:11,yoyo:true,ease:'sine.inOut'}},.4);")
  else:
   other_actor(1220,410,.93,'shrug')
   add(envelope(ident+'-pending',1050,740,False,.8),ident+'-pending',slot*.4)

 elif kind in ['cloud','backup','lan','team','choice','reconcile']:
  if bg=='board-room':lab(lx=180,w=710)
  else:lab()
  if kind=='cloud':
   add(laptop(ident+'-laptop',990,470,560),ident+'-laptop',.9)
   add(cloud(ident+'-cloud',1120,285,'Fichier' if False else 'Tệp ở xa'),ident+'-cloud',2)
  elif kind=='lan':
   add(laptop(ident+'-laptop',875,460,400),ident+'-laptop',.9)
   add(group(ident+'-printer','<path d="M0 80H290V250H0Z" fill="#D7D6CD" stroke="#29231F" stroke-width="5"/><path d="M45 80V-20H245V80" fill="#FFFDF4" stroke="#29231F" stroke-width="4"/><path d="M40 155H250V310H40Z" fill="#FFFDF4" stroke="#29231F" stroke-width="4"/><path d="M75 204H216M75 241H191" class="ink fine"/>',1450,480),ident+'-printer',2)
   add(group(ident+'-lanline','<path d="M1275 735H1438" stroke="#497052" stroke-width="8" fill="none" stroke-dasharray="12 10"/>'),ident+'-lanline',slot*.3)
  elif kind=='backup':
   add(folder(ident+'-file',1110,470,'Được phép'),ident+'-file',1)
   add(group(ident+'-lock','<path d="M0 50V0A50 50 0 0 1 100 0V50" stroke="#29231F" stroke-width="8" fill="none"/><rect x="-15" y="50" width="130" height="120" rx="12" fill="#E9C98E" stroke="#29231F" stroke-width="5"/><circle cx="50" cy="100" r="12" fill="#29231F"/><path d="M50 110V142" stroke="#29231F" stroke-width="7"/>',1530,585),ident+'-lock',slot*.45)
  elif kind in ['team','choice']:
   rows=('Bản nháp','Trao đổi','Ghi lại') if kind=='team' else ('Lưu đúng quyền','Nhớ liên hệ','Chọn việc cần')
   add(notebook(ident+'-list',255,350,rows),ident+'-list',1.1)
   for i in range(3):
    add(group(ident+'-tick'+str(i),f'<path d="M0 0L12 16L39 -24" stroke="{GREEN}" stroke-width="8" fill="none" stroke-linecap="round"/>',650,418+i*84),ident+'-tick'+str(i),3+i*2.7)
  else:
   other_actor(1200,410,.95,'point')
   add(folder(ident+'-file',1040,715,'Đối chiếu'),ident+'-file',slot*.35)

 elif kind=='cash':
  lab();add(money(ident+'-cash',1120,480),ident+'-cash',1)
  add(label(ident+'-done','Giao dịch hoàn tất',1080,805,700,size=43),ident+'-done',slot*.6)
  anim.append(f"tl.to('#{a} .arm-right',{{attr:{{d:'M0 123 Q105 168 232 180'}},duration:.7,ease:'power2.out'}},2);")

 elif kind=='card':
  lab();add(money(ident+'-cash',1000,400),ident+'-cash',.8)
  add(group(ident+'-card','<rect width="350" height="225" rx="17" fill="#BCD7DC" stroke="#29231F" stroke-width="5"/><rect x="38" y="53" width="64" height="50" rx="8" fill="#DDC583" stroke="#29231F" stroke-width="3"/><path d="M36 162H297M36 188H224" class="ink fine"/>',1390,515),ident+'-card',slot*.35)
  add(label(ident+'-path','Đường truyền và cơ chế khác nhau',900,855,900,size=41),ident+'-path',slot*.6)

 elif kind=='stock':
  lab();note(('Tồn kho','Đặt hàng','Lịch giao'),1120,360)
  add(envelope(ident+'-order',1410,790,False,.9),ident+'-order',slot*.5)

 elif kind in ['web','queue','power','care']:
  lab()
  if kind=='web':
   coords=[(1030,400),(1510,390),(1180,720),(1600,720)]
   for i,(px,py) in enumerate(coords):
    add(group(ident+'-node'+str(i),f'<circle r="75" fill="{["#E2ECD9","#D4E5E8","#F5DCAB","#EADBCB"][i]}" stroke="#29231F" stroke-width="5"/>'+text(-44,15,'Mạng',31),px,py),ident+'-node'+str(i),.9+i*1.6)
   add(group(ident+'-webline','<path d="M1105 400L1435 390M1070 468L1145 648M1255 720H1525M1535 465L1580 645M1105 440L1540 680" stroke="#7D8D77" stroke-width="6" fill="none"/>'),ident+'-webline',2)
  elif kind=='queue':
   for i in range(4):add(envelope(ident+'-env'+str(i),1030+i*80,360+i*105,False,1.1),ident+'-env'+str(i),1.0+i*1.8)
   add(label(ident+'-pending','Chờ xử lý',1130,870,500,size=44),ident+'-pending',slot*.6)
  elif kind=='power':
   add(group(ident+'-lamp','<path d="M70 0V370M-30 100H180" stroke="#755334" stroke-width="10" fill="none"/><path d="M27 98Q65 34 114 99Z" fill="#F1CA72" stroke="#29231F" stroke-width="4"/><path d="M47 99Q72 146 96 99" fill="#FFF3B9" stroke="#29231F" stroke-width="3"/><path d="M28 370H123" class="ink"/>',1090,340),ident+'-lamp',1)
   add(group(ident+'-tap','<path d="M0 120V30H165V120M72 30V-15H147" stroke="#7E9A9D" stroke-width="30" fill="none"/><path d="M0 120V30H165V120M72 30V-15H147" stroke="#29231F" stroke-width="4" fill="none"/><path d="M166 155C118 217 205 217 166 155Z" fill="#C7E2E3" stroke="#29231F" stroke-width="3"/>',1510,480),ident+'-tap',slot*.35)
   add(label(ident+'-specific','Xem từng hệ thống cụ thể',950,850,850,size=43),ident+'-specific',slot*.6)
  else:
   add(group(ident+'-monitor','<rect width="330" height="235" rx="18" fill="#DFE7E0" stroke="#29231F" stroke-width="6"/><path d="M25 130H82L105 95L132 160L159 70L195 139H300" stroke="#497052" stroke-width="7" fill="none"/><path d="M163 235V300M70 300H255" class="ink"/>',980,430),ident+'-monitor',1)
   add(folder(ident+'-record',1390,465,'Hồ sơ',False),ident+'-record',slot*.35)
   add(label(ident+'-plan','Quy trình dự phòng',1000,850,800,size=44),ident+'-plan',slot*.6)

 elif kind=='truck':
  lab();body='<path d="M0 0H350V260H0ZM350 90H500L590 180V260H350Z" fill="#E3C48A" stroke="#29231F" stroke-width="6"/><path d="M380 111H483L548 179H380Z" fill="#BCD5D4" stroke="#29231F" stroke-width="4"/><circle class="wheel" cx="107" cy="268" r="51" fill="#7F796D" stroke="#29231F" stroke-width="6"/><circle class="wheel" cx="467" cy="268" r="51" fill="#7F796D" stroke="#29231F" stroke-width="6"/><path d="M105 218V315M57 267H155M465 219V315M417 267H517" stroke="#B7A98D" stroke-width="6"/>'
  add(group(ident+'-truck',body,1080,565),ident+'-truck',1)
  anim.append(f"tl.fromTo('#{ident}-truck',{{x:150}},{{x:-80,duration:4.5,ease:'power1.inOut'}},2);")
  add(envelope(ident+'-address',1250,345,False,.9),ident+'-address',slot*.45)

 elif kind=='kit':
  lab();add(notebook(ident+'-contact',970,350,('Số liên hệ','Tài liệu')),ident+'-contact',.8)
  add(map_prop(ident+'-map',1320,435,'Ngoại tuyến'),ident+'-map',3)
  add(money(ident+'-money',1100,800),ident+'-money',slot*.55)

 elif kind=='end':
  lab(lx=910,w=870)
  other_actor(1240,410,.95,'happy')
  add(label(ident+'-answer','Một việc nhỏ để chuẩn bị hôm nay',420,890,1120,size=47),ident+'-answer',slot*.47)
  anim.append(f"tl.to('#{a} .arm-right',{{attr:{{d:'M0 123 Q95 55 150 -28'}},duration:.8,ease:'back.out(1.2)'}},3);")

 else:raise ValueError(f'Unimplemented shot kind {kind}')

 # General acting: show a real gesture and expression change in every slot.
 length=slot
 if kind!='walk':anim.insert(0,f"tl.fromTo('#{a}',{{x:{-34 if int(ident[1:])%2 else 34}}},{{x:0,duration:.55,ease:'power3.out'}},.15);")
 if kind not in ['walk','end','meet','directions','cash','refresh']:
  gesture='M0 123 Q118 158 185 113' if pose in ['stand','point','think'] else 'M0 123 Q98 143 141 98'
  if bg=='board-room' or pose=='call':
   anim.append(f"tl.to('#{a} .arm-left',{{attr:{{d:'M0 123 Q-140 27 -320 -52'}},duration:.7,repeat:1,yoyo:true,ease:'sine.inOut'}},{length*.44:.3f});")
  else:anim.append(f"tl.to('#{a} .arm-right',{{attr:{{d:'{gesture}'}},duration:.7,repeat:1,yoyo:true,ease:'sine.inOut'}},{length*.44:.3f});")
 if mood in ['worry','curious']:
  mouth='M-28 34 Q0 62 32 33' if kind not in ['refresh','qr','cloud','messages','queue'] else 'M-25 54 Q0 31 28 53'
  anim.append(f"tl.to('#{a} .mouth',{{attr:{{d:'{mouth}'}},duration:.4,ease:'sine.inOut'}},{length*.68:.3f});")
 for i,(pid,when) in enumerate(reveals):
  anim.append(f"tl.fromTo('#{pid}',{{opacity:0,y:{15 if i%2 else -12},scale:.96}},{{opacity:1,y:0,scale:1,duration:.4,ease:'{'power2.out' if i%2 else 'back.out(1.15)'}'}},{min(when,length-1):.3f});")
 return ''.join(arts),'\n'.join(anim)

timeline=[];cursor=0.0
overrides={}
if (P/'voice-timing.json').is_file():overrides=json.loads((P/'voice-timing.json').read_text()).get('durations',{})
for chapter in CHAPTERS:
 weights=[len(b['text'].split())+4 for b in chapter['beats']]
 for j,b in enumerate(chapter['beats']):
  dur=float(overrides.get(b['key'],75*weights[j]/sum(weights)))
  timeline.append({**b,'id':f's{len(timeline)+1:02d}','chapter':chapter['id'],'chapterTitle':chapter['title'],'start':round(cursor,6),'duration':dur})
  cursor+=dur
TOTAL=round(cursor,6)
hosts=[]
for i,b in enumerate(timeline):
 ident=b['id'];start=b['start'];length=b['duration'];host_length=min(length+.28,TOTAL-start)
 art,anim=design(b,ident,length)
 bg=f'<img class="bg" src="assets/backgrounds/{b["bg"]}.webp" alt="Bối cảnh kể chuyện vẽ tay"/>' if b['bg'] else '<div style="position:absolute;inset:0;background:#FFFDF6"></div>'
 camera='' if i%3 else f"tl.fromTo('.camera',{{scale:1}},{{scale:1.018,duration:3.5,ease:'sine.inOut'}},.4);"
 doc=f'''<template><style>{fonts}{CSS}</style><div id="root" data-composition-id="{ident}" data-width="1920" data-height="1080"><div class="stage"><div class="camera">{bg}<svg class="art" viewBox="0 0 1920 1080" xmlns="http://www.w3.org/2000/svg" aria-label="Minh trong cảnh {html.escape(b['key'])}">{art}</svg></div></div></div><script>
const tl=gsap.timeline({{paused:true}});
tl.fromTo('.stage',{{opacity:{1 if i==0 else 0}}},{{opacity:1,duration:.28,ease:'sine.inOut'}},0);
{camera}
[...document.querySelectorAll('#{ident} .actor')].forEach((a,i)=>{{
const id='#'+a.id;
tl.fromTo(id+' .actor-head',{{rotation:-2}},{{rotation:1.8,duration:2.3,repeat:{max(1,int(length/2.3)-1)},yoyo:true,ease:'sine.inOut'}},.35+i*.15);
for(let t=1.4+i*.37;t<{length-.3:.3f};t+=3.8)tl.to(id+' .eyes',{{scaleY:.06,duration:.07,repeat:1,yoyo:true,ease:'power2.inOut'}},t);
tl.to(id+' .pupils',{{x:4,duration:.35,ease:'power2.out'}},2+i*.2);
tl.to(id+' .pupils',{{x:-2,duration:.35,ease:'power2.out'}},{length*.6:.3f}+i*.2);
}});
document.querySelectorAll('#{ident} .pending-dot').forEach((el,i)=>tl.to(el,{{opacity:.22,duration:.35,repeat:5,yoyo:true,ease:'sine.inOut'}},1.2+(i%3)*.18));
{anim}
window.__timelines=window.__timelines||{{}};window.__timelines['{ident}']=tl;
</script></template>'''
 (P/f'compositions/{ident}.html').write_text(doc)
 hosts.append(f'<div id="{ident}" class="clip" data-composition-id="{ident}" data-composition-src="compositions/{ident}.html" data-start="{start:.6f}" data-duration="{host_length:.6f}" data-width="1920" data-height="1080" data-track-index="{i+1}" data-track-kind="graphics" style="z-index:{i+1}"></div>')

audio=''
if (P/'voice-timing.json').is_file():
 voice=json.loads((P/'voice-timing.json').read_text()).get('narration')
 if voice:
  assert (P/voice).is_file(),'Final narration is missing'
  audio=f'<audio id="user-narration" class="clip" data-start="0" data-duration="{TOTAL}" data-track-index="50" src="{html.escape(voice)}" data-volume="1"></audio>'
root=f'''<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=1920,height=1080"><title>Nếu Internet biến mất trong 24 giờ</title><style>{fonts}*{{box-sizing:border-box}}html,body{{margin:0;width:1920px;height:1080px;overflow:hidden;background:#FFF8E8}}#root,.clip{{position:absolute;inset:0}}</style><script src="assets/gsap.min.js"></script></head><body><div id="root" data-composition-id="main" data-start="0" data-duration="{TOTAL}" data-width="1920" data-height="1080" data-fps="24">{''.join(hosts)}{audio}</div><script>window.__timelines=window.__timelines||{{}};window.__timelines.main=gsap.timeline({{paused:true}});</script></body></html>'''
(P/'index.html').write_text(root)
(P/'timeline.json').write_text(json.dumps({'duration':TOTAL,'fps':24,'width':1920,'height':1080,'silent':not bool(audio),'shots':timeline},ensure_ascii=False,indent=2))
print(f'Built {len(timeline)} shots, {TOTAL:.3f}s, 1920×1080, 24fps; audio={bool(audio)}')
