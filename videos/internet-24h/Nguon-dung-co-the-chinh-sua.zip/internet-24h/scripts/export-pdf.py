from pathlib import Path
import sys
from xml.sax.saxutils import escape
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from story import CHAPTERS
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.pagesizes import A4
from reportlab.lib.colors import HexColor

P=Path(__file__).resolve().parents[1]
pdfmetrics.registerFont(TTFont('VoiceBody','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('VoiceBold','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
styles={
 'chapter':ParagraphStyle('chapter',fontName='VoiceBold',fontSize=18,leading=25,spaceAfter=18,textColor=HexColor('#29231F')),
 'hint':ParagraphStyle('hint',fontName='VoiceBody',fontSize=10,leading=15,spaceAfter=15,textColor=HexColor('#695E50')),
 'body':ParagraphStyle('body',fontName='VoiceBody',fontSize=13,leading=21,spaceAfter=15,textColor=HexColor('#29231F')),
}
items=[]
for i,c in enumerate(CHAPTERS):
 if i:items.append(PageBreak())
 items.append(Paragraph(f"Phần {c['id']}: {escape(c['title'])}",styles['chapter']))
 items.append(Paragraph('Chỉ đọc các đoạn kể chuyện bên dưới. Đọc tự nhiên; hình sẽ được căn lại theo bản thu.',styles['hint']))
 for b in c['beats']:items.append(Paragraph(escape(b['text']),styles['body']))
def footer(canvas,doc):
 canvas.saveState();canvas.setFont('VoiceBody',9);canvas.setFillColor(HexColor('#695E50'))
 canvas.drawString(43,25,'Nếu Internet biến mất trong 24 giờ · Bản lời đọc')
 canvas.drawRightString(A4[0]-43,25,str(doc.page));canvas.restoreState()
doc=SimpleDocTemplate(str(P/'delivery/Kich-ban-thu-voice.pdf'),pagesize=A4,rightMargin=43,leftMargin=43,topMargin=42,bottomMargin=45,title='Nếu Internet biến mất trong 24 giờ — lời đọc',author='Kịch bản dự án')
doc.build(items,onFirstPage=footer,onLaterPages=footer)
print('Wrote delivery/Kich-ban-thu-voice.pdf')
