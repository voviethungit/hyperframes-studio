"""Export user-facing recording copy and the editor's shot map from one source."""
from pathlib import Path
import sys,json,zipfile
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from story import CHAPTERS
from docx import Document
from docx.shared import Pt,Cm

P=Path(__file__).resolve().parents[1];D=P/'delivery';D.mkdir(exist_ok=True)
timeline=json.loads((P/'timeline.json').read_text())
shots={b['key']:b for b in timeline['shots']}
title='Nếu Internet biến mất trong 24 giờ'
clean='\n\n'.join(b['text'] for c in CHAPTERS for b in c['beats'])+'\n'
(D/'Loi-doc-day-du.txt').write_text(clean)
guide='''# Thu voice cho “Nếu Internet biến mất trong 24 giờ”

Bản hình hiện tại dài 10:00, 16:9, chưa có âm thanh. Các mốc thời gian là mốc dựng dự kiến; tôi sẽ căn lại cảnh, chuyển động và điểm hiện chữ theo giọng bạn gửi. Thời lượng bản hoàn thiện có thể thay đổi theo nhịp đọc.

Bạn chỉ cần thu lời trong **Loi-doc-day-du.txt** hoặc tài liệu Word. Trong tài liệu Word, phần tiêu đề và tên chương giúp tìm đoạn; chỉ đọc các đoạn văn kể chuyện.

- Đọc tự nhiên, rõ lời, như đang kể một câu chuyện cho một người nghe. Có thể hơi hài ở đầu và bình tĩnh hơn khi giải thích.
- Nghỉ khoảng 1–2 giây giữa các đoạn. Không cần đuổi theo thời gian hiển thị trong bản hình.
- Thu giọng sạch, không nhạc nền hoặc hiệu ứng; giữ khoảng cách tới micro tương đối đều.
- Nếu đọc vấp, dừng một nhịp rồi đọc lại cả câu. Bạn có thể giữ lần đọc lại trong file để tôi cắt.
- Gửi một file WAV/MP3/M4A đầy đủ, hoặc tám file tương ứng tám chương. Nếu tách file, đặt tên 01 đến 08 theo thứ tự.

Trong **Loi-doc-8-phan.zip** có tám tệp TXT chỉ chứa lời đọc. **Kich-ban-va-phan-canh.md** có lời dẫn, mốc dự kiến, ID cảnh và ý đồ hình ảnh để đối chiếu khi chỉnh sửa; phần ghi chú hình ảnh không phải lời cần đọc.

Khi có voice: nhận diện các câu và khoảng nghỉ, loại bỏ lần đọc lỗi nếu có, điều chỉnh thời lượng từng cảnh, căn hành động/đồ vật theo câu tương ứng, rồi xuất bản có tiếng. Nếu một câu khác đáng kể với kịch bản, sẽ ưu tiên nội dung bản thu và chỉnh hình phù hợp.

Nội dung là một tình huống giả tưởng về gián đoạn Internet công cộng. Các ảnh hưởng tới điện, mạng nội bộ, mạng thoại, GPS và thanh toán được mô tả theo điều kiện của từng hệ thống, không phải dự báo một sự cố thật.
'''
(D/'Huong-dan-thu-voice.md').write_text(guide)
def tc(t):
 t=round(t);return f'{t//60:02}:{t%60:02}'
storyboard=[f'# {title}\n', 'Bản hình dự kiến: 10:00 · 1920×1080 · 24fps · chờ voice của bạn.\n', 'Các mốc dưới đây dùng để dựng hình; hãy thu lời tự nhiên, không cần bám từng giây.\n']
kind_notes={
'phone':'Minh xem điện thoại và chờ tải; đồng hồ sáng sớm.', 'refresh':'Thao tác tải lại; biểu tượng kết nối chưa có phản hồi.',
'router':'Bộ phát vẫn sáng; tách mạng gần và kết nối ra ngoài.', 'talk':'Minh trao đổi với người hàng xóm trên phố.',
'premise':'Minh và đồng hồ; làm rõ giả định 24 giờ.', 'offline-phone':'Điện thoại với các dữ liệu đã lưu.',
'network':'Bộ phát, đường nối và đám mây ở xa.', 'call':'Minh gọi thường; chú thích điều kiện mạng thoại.',
'gps':'Vệ tinh và tấm bản đồ; vị trí khác dữ liệu bản đồ.', 'address':'Chép địa chỉ và số liên hệ vào sổ.',
'ride':'Điện thoại đang chờ và chiếc xe vẫn ở ngoài đường.', 'map':'Mở tấm bản đồ đã lưu và hiện đường đi.',
'directions':'Hai nhân vật hỏi đường, tay chỉ hướng và tấm bản đồ.', 'walk':'Minh có bước chân và chuyển vị trí trong phố.',
'arrival':'Minh và đồng nghiệp trước các công việc đang chờ.', 'cloud':'Máy tính và tệp nằm ở xa.',
'local':'Tệp đã tải xuống, ghi rõ phiên bản.', 'lan':'Máy tính và máy in nối trong mạng nội bộ.',
'backup':'Thư mục được phép lưu và biểu tượng khóa.', 'team':'Danh sách công việc và dấu hoàn tất.',
'qr':'Điện thoại, ký hiệu QR và trạng thái chưa xác nhận.', 'cash':'Trao tiền mặt, chuyển động tay và xác nhận mua hàng.',
'card':'Tiền mặt và thẻ; các đường truyền khác nhau.', 'ledger':'Ghi lại các khoản để đối chiếu.',
'stock':'Danh sách tồn kho, đặt hàng và lịch giao.', 'web':'Các mạng nhỏ nối với nhau, lộ từng mắt xích.',
'queue':'Các yêu cầu xếp thành hàng chờ.', 'power':'Đèn và vòi nước, không đồng nhất mất mạng với mất điện.',
'care':'Thiết bị tại chỗ, hồ sơ và quy trình dự phòng.', 'truck':'Xe giao hàng di chuyển, thông tin địa chỉ bị chậm.',
'cafe':'Minh ở quán vào buổi tối.', 'meet':'Hai người gặp nhau bên bàn và trao đổi trực tiếp.',
'offline-work':'Cuốn sổ công việc có phần đã làm và phần còn thiếu.', 'kit':'Số liên hệ, bản đồ và cách thanh toán dự phòng.',
'calm':'Minh đọc vài trang sách trong phòng.', 'return':'Điện thoại và kết nối lần lượt trở lại.',
'messages':'Thông báo xuất hiện dồn lại quanh Minh.', 'reconcile':'Hai đồng nghiệp đối chiếu thư mục công việc.',
'choice':'Đánh dấu các lựa chọn chuẩn bị cho lần sau.', 'end':'Minh trên phố và câu hỏi kết thúc dành cho người xem.'}
doc=Document();sec=doc.sections[0];sec.top_margin=Cm(1.8);sec.bottom_margin=Cm(1.8)
normal=doc.styles['Normal'];normal.font.name='Arial';normal.font.size=Pt(13)
normal.paragraph_format.space_after=Pt(10)
doc.add_heading(title,0)
doc.add_paragraph('Bản lời đọc để thu âm — chỉ đọc các đoạn kể chuyện. Tên chương và mốc thời gian giúp tìm đoạn, không cần đọc thành tiếng.')
doc.add_paragraph('Đọc tự nhiên; bản hình sẽ được căn lại theo voice thực tế. Có thể thu một file hoặc tám phần.')
with zipfile.ZipFile(D/'Loi-doc-8-phan.zip','w',zipfile.ZIP_DEFLATED) as z:
 for c in CHAPTERS:
  start=shots[c['beats'][0]['key']]['start'];last=shots[c['beats'][-1]['key']];end=last['start']+last['duration']
  doc.add_heading(f"Phần {c['id']}: {c['title']}",level=1)
  storyboard.append(f"\n## Phần {c['id']} · {tc(start)}–{tc(end)} · {c['title']}\n")
  part='\n\n'.join(b['text'] for b in c['beats'])+'\n'
  z.writestr(f"{c['id']}-loi-doc.txt",part)
  for b in c['beats']:
   doc.add_paragraph(b['text'])
   s=shots[b['key']]
   storyboard.append(f"\n### {s['id']} · {tc(s['start'])}–{tc(s['start']+s['duration'])}\n\n{b['text']}\n\n*Hình: {kind_notes[b['kind']]}*\n")
doc.save(D/'Kich-ban-thu-voice.docx')
(D/'Kich-ban-va-phan-canh.md').write_text('\n'.join(storyboard))
(D/'timing-du-kien.json').write_text(json.dumps(timeline,ensure_ascii=False,indent=2))
print('Exported clean TXT, DOCX, eight-part ZIP, recording guide, storyboard and timing JSON.')
