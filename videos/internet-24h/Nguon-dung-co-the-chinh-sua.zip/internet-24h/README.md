# Nếu Internet biến mất trong 24 giờ

Original Vietnamese illustrated story: 8 chapters, 40 shots, default 600 seconds, 1920×1080, 24fps. User records their own narration later. This is a silent visual draft, with timing to be revised from the actual recording.

Canonical narration and shot intentions: `story.py`. `python scripts/build.py` writes forty independent scene compositions and `timeline.json`. `python scripts/export-recording.py` writes clean recording TXT, eight-part ZIP, Word document, storyboard and handoff guide to `delivery/`.

`/workspace/.onboarding/bin/hyperframes check` runs the full checks. Render: `hyperframes render --quality standard --crf 25 --fps 24 --workers 4 --output renders/internet-24h-visual-draft.mp4`.

Use the local project assets; the build has no dependency on older project directories. Local GSAP, fonts and backgrounds avoid render-time network calls. Background WEBPs are delivery-oriented copies; the original PNG artwork is retained.

When narration arrives, create `voice-timing.json` with `durations` keyed by the forty stable shot keys and `narration` as a local audio asset path. Measure the audio before assigning these durations; the current proportional slots are provisional. The builder recomputes all start times and total length, then mounts the real narration only when that file is present. Retune action cue offsets against actual sentence timings before final export.

Keep the private voice recording outside public Git files. Publish only the final requested output video and the recording/storyboard exports. Do not publish private uploaded reference clips or voice samples.
