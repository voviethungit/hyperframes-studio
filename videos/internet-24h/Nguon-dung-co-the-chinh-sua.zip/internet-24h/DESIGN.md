# Internet mất trong 24 giờ — hướng hình ảnh đã chọn

Keep the user-approved demo3-derived look from plus-cong-luc-story16x9: original white-headed stickman with brown-black pen outlines, expressive separate eye/brow/mouth parts, warm illustrated rooms, occasional paper cutaway explanations. This is an original hypothetical story, not a factual report of an outage that happened.

Palette: ink #29231F; paper #FFF8E8; ochre #C28B43; interruption red #B84132; completion sage #497052; pale screen blue #C7E2E3. Use the existing local Be Vietnam Pro 800 at 34–60px for sparse physical paper labels. No permanent lower thirds or subtitles before narration exists.

Six environments: home, study noticeboard, neighborhood street, shared office, grocery counter, evening cafe. The first two reuse the approved original art; the other four are newly generated original backgrounds. No reference video frames or private voice samples enter this film.

The protagonist Minh keeps the same round head and rig throughout. The colleague has a small hair detail to distinguish them. Actor height about 530–580px in medium-wide scenes. Feet contact the room floor. A checkout clerk is clipped at the counter rather than drawing legs over furniture.

Motion: 24fps long-form visual draft, finite blinks, gaze changes, articulated arms, visible prop handling, short walk cycles and diagram stroke reveals. Camera reframing is limited to a few seconds of a shot, then settles so labels remain readable. Use 0.25–0.35s dissolves with transparent composition roots and opaque backgrounds inside the animated stage.

Avoid: dark glass-card layouts, statistic dashboards, unrelated chapter chrome, endless loading loops, fixed captions pretending to follow absent voice, identical full-scene motion in every shot, a claim that loss of public Internet means every electrical/telecom/payment system stops.
