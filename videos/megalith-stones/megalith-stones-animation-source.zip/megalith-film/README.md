# История в Палочках — complete local animated film

Russian narration master: 30:25.410612. Horizontal 1920×1080. Nominal 25 fps.
234 semantic scene entries and 522 acoustically aligned narration phrases.

The film uses original deterministic Canvas 2D drawings and articulated workers,
then browser capture and FFmpeg H.264 encoding. It does not claim HeyGen cloud
generation. No synthetic replacement voice, subtitles, music or lip sync.

The supplied original MP3 is private. Only the authorized completed movie includes
its narration; no standalone raw voice, analysis WAV or reference video is bundled.

## Rebuild

Install Node.js, Chromium, FFmpeg, Python 3.12, `puppeteer-core`, and PyAV (`av`).
The scene data and renderer are standalone and need no cloud generation API.

1. Run `python scripts/build.py`.
2. Serve this folder at `http://127.0.0.1:3012/`, for example with Python's HTTP server.
3. Run `node scripts/inspect.cjs` to check all scene midpoints.
4. Run `node scripts/render.cjs --frames 45636 --workers 4`.
5. Concatenate the encoded segments with FFmpeg concat demuxer and `-c copy` to
   `renders/silent-full.mp4` using the generated `renders/concat.txt`.
6. Put the unchanged source MP3 at a private location. Remux it with FFmpeg,
   without re-encoding, to `private/master-audio.mp4`. Do not substitute a different
   audio track or use a generated voice.
7. Run `python scripts/mux.py`; it preserves every narration packet and shortens
   only the last video sample's presentation duration to the exact master endpoint.
8. Verify full-file decoding, duration, video frames and both encoded/decoded
   audio hashes against the original MP3 before delivering.

`CHROME_PATH` can select the installed Chromium binary. The capture scripts use
the installed `puppeteer-core`; this workspace also has a local fallback package.
On other machines install the package normally. `index.html` is a deterministic
frame viewer; call `renderFrame(seconds)` in its console to inspect a specific time.

The continuation notes and narration timings are in `assets/manifest.json` and
`assets/phrases.json`. The source relies on the user's script, not equal scene
lengths. The final edit retains the model's 40 ms acoustic timing resolution.
