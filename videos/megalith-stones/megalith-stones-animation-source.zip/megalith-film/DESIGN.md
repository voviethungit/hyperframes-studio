# История в Палочках — finished film identity

Coherent expressive flat 2D historical stick-figure explainer. Warm light canvas,
clean dark outlines, pale round heads, colored period clothing, readable hands,
and deliberate physical movement. Diagram clarity takes priority over decoration.

Palette: warm ground #F4ECD7; ink #253235; heads #FFFEF8; terracotta #D46B3D;
blue #3B84A0; ochre #E4AE44; sage #7F9B70; plum #8D6B8B. Muted stone and timber
separate from people and ropes. Culture-specific landscape/architecture changes
at the measured narration boundaries. Cyrillic overlays use DejaVu Sans, only
short intentional mechanism or reconstruction labels; no automatic subtitles.

Black-line articulated limbs, stable hand grips, period clothing shapes and fixed
identity colors. The load never flies, supports bear weight, ropes have anchors,
fulcrums are visible, and each haul continues screen-right. Cuts preserve state.

Avoid: photorealistic faces, anime, 3D, explanatory text cards replacing action,
meaningless bouncing, fake environmental writing, modern machines in old scenes,
new voice, voice tempo changes, additional dialogue or lip sync.

Rendering implementation: deterministic Canvas 2D mechanical rigs, browser frame
capture and FFmpeg. This is a local animated production, not HeyGen cloud clips.
