import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
manifest=json.loads((ROOT/'assets/manifest.json').read_text())
phrases=json.loads((ROOT/'assets/phrases.json').read_text())
data=json.dumps({'scenes':manifest['scenes'],'phrases':phrases},ensure_ascii=False).replace('</','<\\/')
html='''<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>История в Палочках</title><style>*{box-sizing:border-box}html,body{margin:0;width:1920px;height:1080px;overflow:hidden;background:#F4ECD7}canvas{display:block;width:1920px;height:1080px}</style><canvas id="film" width="1920" height="1080"></canvas><script>window.FILM_DATA=__DATA__;</script><script src="film.js"></script></html>'''
(ROOT/'index.html').write_text(html.replace('__DATA__',data))
print('Built deterministic visual timeline',len(manifest['scenes']),'scenes,',len(phrases),'phrases')
