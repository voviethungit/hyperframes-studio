"""Mux all original narration packets and set the last video sample's exact end."""
from pathlib import Path
from fractions import Fraction
import av,json,heapq

ROOT=Path(__file__).resolve().parents[1]
DURATION=Fraction(1825410612,1000000)
ROOT.joinpath('delivery').mkdir(exist_ok=True)
segments=json.loads((ROOT/'renders/segments.json').read_text())
containers=[av.open(x['file']) for x in segments]
video=containers[0]
audio=av.open(str(ROOT/'private/master-audio.mp4'))
output=av.open(str(ROOT/'delivery/megalith-stones-complete.mp4'),'w',options={'movflags':'+faststart','movie_timescale':'1000000','video_track_timescale':'1000000'})
vs=output.add_stream_from_template(video.streams.video[0]);vs.time_base=Fraction(1,1000000)
aus=output.add_stream_from_template(audio.streams.audio[0])
output.metadata['title']='Как люди поднимали многотонные камни без современной техники?'
output.metadata['artist']='История в Палочках'
output.metadata['comment']='Local 2D stick-figure animation. Original Russian narration retained without re-encoding. No HeyGen cloud generation.'
vp=[]
for segment,container in zip(segments,containers):
    assert container.streams.video[0].codec_context.extradata==video.streams.video[0].codec_context.extradata
    packets=[p for p in container.demux(video=0) if p.dts is not None]
    assert len(packets)==segment['end_frame']-segment['start_frame']
    for j,p in enumerate(packets):
        p.pts=p.dts=(segment['start_frame']+j)*40000
        p.time_base=Fraction(1,1000000)
    vp.extend(packets)
patch_root=ROOT/'renders/patches'
patches=[]
if patch_root.exists():
    for done in sorted(patch_root.glob('*.done')):
        item=json.loads(done.read_text());a=item['start_frame'];b=item['end_frame']
        container=av.open(item['file']);containers.append(container)
        assert container.streams.video[0].codec_context.extradata==video.streams.video[0].codec_context.extradata
        packets=[p for p in container.demux(video=0) if p.dts is not None]
        assert len(packets)==b-a and packets[0].is_keyframe
        for j,p in enumerate(packets):
            p.pts=p.dts=(a+j)*40000;p.time_base=Fraction(1,1000000)
        vp[a:b]=packets;patches.append([a,b])
# At every replacement end, the next original or replacement packet must reset
# the decoder. All capture encoders use -bf 0, so no old frame needs a future one.
for a,b in patches:
    if b<len(vp):assert vp[b].is_keyframe,('Unsafe splice',a,b)
ap=[p for p in audio.demux(audio=0) if p.dts is not None]
last=vp[-1]
last.duration=int((DURATION-last.pts*last.time_base)/last.time_base)
assert last.duration>0 and last.pts*last.time_base+last.duration*last.time_base==DURATION
vi=ai=0
while vi<len(vp) or ai<len(ap):
    take_video=ai==len(ap) or (vi<len(vp) and vp[vi].dts*vp[vi].time_base<=ap[ai].dts*ap[ai].time_base)
    if take_video:p=vp[vi];p.stream=vs;vi+=1
    else:p=ap[ai];p.stream=aus;ai+=1
    output.mux(p)
output.close()
for container in containers:container.close()
audio.close()
record={'video_packets':len(vp),'original_audio_packets':len(ap),'last_video_sample_duration_microseconds':last.duration,'target_duration_seconds':float(DURATION),'audio_reencoded':False,'camera_refinement_frame_ranges':patches}
(ROOT/'delivery/mux-report.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2))
