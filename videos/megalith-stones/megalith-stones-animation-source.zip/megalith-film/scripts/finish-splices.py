"""Extend camera replacements to actual decoder-reset boundaries, without re-encoding the movie."""
import av,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
segments=json.loads((ROOT/'renders/segments.json').read_text())
keys=set()
for s in segments:
    cont=av.open(s['file'])
    for j,p in enumerate(p for p in cont.demux(video=0) if p.dts is not None):
        if p.is_keyframe:keys.add(s['start_frame']+j)
    keys.add(s['end_frame']);cont.close()
items=[json.loads(p.read_text()) for p in (ROOT/'renders/patches').glob('*.done')]
for item in items:
    b=item['end_frame']
    if b not in keys:
        end=min(k for k in keys if k>b)
        print('Extending refinement to original keyframe',b,end,flush=True)
        subprocess.run(['node',str(ROOT/'scripts/render.cjs'),'--start',str(b),'--frames',str(end-b),'--workers','1','--out',str(ROOT/'renders/patches')],check=True)
