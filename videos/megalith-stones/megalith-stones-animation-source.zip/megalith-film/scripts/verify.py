import subprocess,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
FILE=ROOT/'delivery/megalith-stones-complete.mp4'
def ffhash(codec):
    return subprocess.check_output(['ffmpeg','-v','error','-i',str(FILE),'-map','0:a:0','-c:a',codec,'-f','hash','-hash','sha256','-'],text=True).strip().split('=')[-1]
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(FILE)]))
v=next(x for x in probe['streams'] if x['codec_type']=='video');a=next(x for x in probe['streams'] if x['codec_type']=='audio')
encoded=ffhash('copy');decoded=ffhash('pcm_s16le')
motion=json.loads((ROOT/'private/motion-report.json').read_text())
report={'file':FILE.name,'size_bytes':FILE.stat().st_size,'sha256':hashlib.sha256(FILE.read_bytes()).hexdigest(),'duration_seconds':float(probe['format']['duration']),'video_duration_seconds':float(v['duration']),'audio_codec':a['codec_name'],'width':v['width'],'height':v['height'],'nominal_fps':v['r_frame_rate'],'video_frames':int(v['nb_frames']),'audio_packet_payload_sha256':encoded,'decoded_narration_pcm_s16le_sha256':decoded,'checks':{'duration_matches_master_exactly':probe['format']['duration']=='1825.410612','video_end_matches_master_exactly':v['duration']=='1825.410612','resolution_1920x1080':(v['width'],v['height'])==(1920,1080),'all_45636_frames_present':int(v['nb_frames'])==45636,'original_encoded_audio_unchanged':encoded=='4051ce8510e4974f7d2c6c9ebd942ac65d3f6fb35a54d112d9a20fad9981b0db','original_decoded_audio_samples_unchanged':decoded=='eb0781c8a3cc281298a24324dec2dfbf4de052328ec8ee6410fd8a8f8dd0c314','all_234_scenes_have_visible_motion':len(motion)==234 and all(x['mean_pixel_change']>.005 for x in motion),'single_original_narration_track':sum(x['codec_type']=='audio' for x in probe['streams'])==1},'renderer':'Deterministic Canvas 2D plus FFmpeg/PyAV; no HeyGen cloud generation','visual_review':'All 234 scene midpoint frames inspected; geometry/rig corrections and camera refinements applied; motion measured across three positions per scene.','real_time_human_watch_of_entire_video':False,'human_listening_review':False}
print('Checking complete encoded file decode...',flush=True)
subprocess.run(['ffmpeg','-v','error','-threads','3','-i',str(FILE),'-map','0:v:0','-map','0:a:0','-f','null','-'],check=True)
report['checks']['complete_video_and_audio_decode_without_error']=True
report['all_checks_pass']=all(report['checks'].values())
(ROOT/'delivery/final-video-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
assert report['all_checks_pass'],report
print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)
